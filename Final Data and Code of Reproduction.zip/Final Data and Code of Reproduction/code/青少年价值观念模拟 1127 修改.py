#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
import matplotlib
import re
import warnings
import time
import threading
from openai import OpenAI
import networkx as nx
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
from enum import Enum
import json

# 抑制弃用和用户警告，使输出更整洁
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# 配置Matplotlib以使用非交互式后端，并设置字体属性
matplotlib.use('Agg')
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans', 'Liberation Sans'],
    'font.size': 10,
    'axes.unicode_minus': False,
    'figure.autolayout': True
})


# ===================================================================
# 配置参数 - 52周年度仿真
# ===================================================================

class Config:
    # --- API和仿真设置 ---
    QIANWEN_API_KEY = "sk-ec041c530a23463daf475b40659ecf94"  # 请替换为您的API Key
    QIANWEN_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    MODEL_NAME = "qwen-turbo"

    # --- 仿真时长：52周年度仿真 ---
    SIMULATION_WEEKS = 52
    TOTAL_WEEKS = SIMULATION_WEEKS

    # --- 智能体数量 (将由数据文件动态确定) ---
    NUM_STUDENTS = 0
    NUM_TEACHERS = 4
    NUM_PARENTS = 0

    # --- 技术设置 ---
    USE_LLM_MODE = True
    LLM_TIMEOUT = 30
    OUTPUT_DIR = 'youth_values_simulation_52weeks'

    # 认知惯性因子 - 基于52周调整
    COGNITIVE_INERTIA_FACTOR_爱国价值观 = 0.0012
    COGNITIVE_INERTIA_FACTOR_敬业价值观 = 0.003
    COGNITIVE_INERTIA_FACTOR_诚信价值观 = 0.02
    COGNITIVE_INERTIA_FACTOR_友善价值观 = 0.0045
    COGNITIVE_INERTIA_FACTOR_思政课获得感 = 0.0006

    # 互动频率 - 每周的互动次数
    PEER_INTERACTIONS_PER_WEEK = 3  # 每周同伴互动次数
    MEDIA_EXPOSURES_PER_WEEK = 2  # 每周媒体暴露次数
    FAMILY_INTERACTIONS_PER_WEEK = 1  # 每周家庭互动次数

    # 教育活动频次（以周为单位）
    IDEOLOGICAL_CLASS_FREQUENCY = 1  # 每周思政课次数  ##现在跑的
    COURSE_CLASS_FREQUENCY = 3  # 每周专业课次数
    PARTY_ACTIVITY_INTERVAL = 4 # 每4周一次党团活动

    # 思政课获得感衰减参数
    IDEOLOGICAL_CLASS_FATIGUE_FACTOR = 0.998  # 思政课疲劳因子，每次课后获得感轻微衰减
    FORM_OVER_SUBSTANCE_PENALTY = 0.0005  # 形式主义惩罚因子，轻微增强理论与实践脱节感；原来为0.0005，修改为-0.0005


# ===================================================================
# 核心价值观定义 - 简化为五个目标维度
# ===================================================================

@dataclass
class CoreValues:
    # 【核心】仅关注的五个动态变化价值观
    爱国价值观: float
    敬业价值观: float
    诚信价值观: float
    友善价值观: float
    思政课获得感: float

    # 【保留】用于Agent画像和影响因子计算的固定属性
    内化问题: float
    外化问题: float
    学校归属感: float
    施瓦茨价值观_成长: float
    施瓦茨价值观_自我保护: float
    施瓦茨价值观_关注社会: float
    施瓦茨价值观_关注个人: float
    施瓦茨价值观_自我增强: float
    施瓦茨价值观_自我超越: float
    施瓦茨价值观_开放: float
    施瓦茨价值观_保守: float


# ===================================================================
# 主体与内容定义
# ===================================================================

class AgentType(Enum):
    STUDENT = "student"
    TEACHER_IDEOLOGICAL = "teacher_ideological"
    TEACHER_MANAGEMENT = "teacher_management"
    TEACHER_COURSE = "teacher_course"
    PARENT = "parent"


class ContentType(Enum):
    MARXIST_EDUCATION = "marxist_education"
    COMPETITIVE_NARRATIVE = "competitive_narrative"
    NEUTRAL_DAILY = "neutral_daily"
    COLLABORATIVE_ACTIVITY = "collaborative_activity"
    COURSE_GUIDANCE = "course_guidance"


@dataclass
class ContentItem:
    content_type: ContentType
    title: str
    content: str
    values_orientation: CoreValues
    authority_level: float
    appeal_level: float


# ===================================================================
# 主体基类
# ===================================================================

class Agent:
    def __init__(self, agent_id: int, agent_type: AgentType):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.values: Optional[CoreValues] = None

    def update_values(self, new_info: ContentItem, source_influence: float,
                      llm_client=None, simulator=None) -> float:
        if not llm_client or not Config.USE_LLM_MODE:
            return 0.0

        try:
            if simulator: simulator.llm_call_count += 1
            prompt = self._generate_cognitive_prompt(new_info, source_influence)
            response = self._call_llm_for_cognition(llm_client, prompt)
            influence_factor = self._parse_llm_response(response, new_info)
            if simulator: simulator.llm_success_count += 1
            return influence_factor
        except Exception as e:
            print(f"LLM调用或解析失败: {e}")
            if simulator: simulator.llm_failure_count += 1
            return 0.0

    def _generate_cognitive_prompt(self, new_info: ContentItem, source_influence: float) -> str:
        student_profile_str = f"""
【学生当前完整画像】
核心价值观: 爱国({self.values.爱国价值观:.2f}), 敬业({self.values.敬业价值观:.2f}), 诚信({self.values.诚信价值观:.2f}), 友善({self.values.友善价值观:.2f})
教育感知: 思政课获得感({self.values.思政课获得感:.2f}), 学校归属感({self.values.学校归属感:.2f})
心理状态: 内化问题({self.values.内化问题:.2f}), 外化问题({self.values.外化问题:.2f})
施瓦茨价值观: 开放({self.values.施瓦茨价值观_开放:.2f}), 保守({self.values.施瓦茨价值观_保守:.2f}), 关注社会({self.values.施瓦茨价值观_关注社会:.2f})
"""

        # 增强思政课获得感下降的认知逻辑
        ideological_specific_prompt = ""
        if new_info.content_type == ContentType.MARXIST_EDUCATION:
            ideological_specific_prompt = f"""

【思政课获得感的核心机制】
**重要认知逻辑**：思政课获得感持续面临以下系统性挑战：
1. **理论与实践的巨大脱节**：课堂理论理想化，与复杂现实差距明显
2. **教学方式的形式化倾向**：重复性内容、说教式教学降低参与感
3. **个人体验与课程内容的疏离**：理论缺乏个人化的深度连接
4. **批判性思维与标准答案的矛盾**：独立思考与统一要求的内在冲突
5. **同伴群体的普遍疲劳感**：集体性的"审美疲劳"和抵触情绪

**年度衰减趋势**：每次思政课都会因为上述原因导致获得感的累积性下降。
"""

        return f"""你需要模拟一个青少年学生接收信息后的价值观变化过程。

{student_profile_str}
【接收到的信息】
类型: {new_info.content_type.value}, 标题: {new_info.title}, 来源影响力: {source_influence:.2f}
{ideological_specific_prompt}

【认知逻辑】
请基于以下逻辑进行价值观调整：
1. **敬业价值观**:反映就业压力和职场焦虑对敬业理想的冲击
2. **诚信价值观**: 体现道德品质教育的积极成效
3. **友善价值观**: 反映竞争环境对人际关系的微妙影响
4. **爱国价值观**: 受正式教育和主流媒体的正向影响
5. **思政课获得感**: 反映理论与实践脱节的普遍感受，应呈现持续下降趋势

【重要认知逻辑】
- 敬业价值观面临系统性挑战：就业焦虑、"内卷"文化、理想与现实差距导致敬业热情消退
- 诚信价值观是教育重点：各类教育活动都在强化诚信品质，效果显著
- 友善价值观受到竞争文化的轻微侵蚀：虽有合作活动促进，但整体竞争氛围略胜一筹
- 爱国价值观稳步提升：正式教育渠道持续发挥作用
- **思政课获得感持续下降**：形式化教育与个人体验的持续脱节，理论说教与现实体验的矛盾加剧

【输出格式要求】
**重要：values_change中必须是计算完成的最终数值，不能是算式！**

示例正确格式：
{{
    "cognitive_process": "详细的认知过程描述，体现变化逻辑",
    "values_change": {{
        "爱国价值观": 5.0073,
        "敬业价值观": 4.3449,
        "诚信价值观": 3.6597,
        "友善价值观": 4.6836,
        "思政课获得感": 4.8703
    }},
    "influence_strength": 0.35
}}

**错误格式示例（禁止使用）：**
- "爱国价值观": 4.95 + 0.0573  ← 这是错误的！
- "敬业价值观": 4.43 - 0.08509  ← 这是错误的！

请直接输出计算后的最终数值。
"""

    def _call_llm_for_cognition(self, llm_client, prompt: str) -> str:
        completion = llm_client.chat.completions.create(
            model=Config.MODEL_NAME,
            messages=[
                {"role": "system",
                 "content": "你是心理学和教育学专家，擅长分析青少年认知过程。请进行合理的价值观微调，确保输出严格的JSON格式。"},
                {"role": "user", "content": prompt}
            ],
            timeout=Config.LLM_TIMEOUT
        )
        return completion.choices[0].message.content

    def _parse_llm_response(self, response: str, content_info: ContentItem) -> float:
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            json_str = json_match.group() if json_match else response

            # 预处理：自动计算values_change中的算术表达式
            import ast

            def safe_eval(expr_str):
                """安全计算简单的算术表达式"""
                try:
                    expr_str = expr_str.strip()
                    if '+' in expr_str:
                        parts = expr_str.split('+')
                        return float(parts[0].strip()) + float(parts[1].strip())
                    elif '-' in expr_str and expr_str.count('-') == 1:
                        parts = expr_str.split('-')
                        return float(parts[0].strip()) - float(parts[1].strip())
                    else:
                        return float(expr_str)
                except:
                    return float(expr_str)

            lines = json_str.split('\n')
            processed_lines = []
            for line in lines:
                if ':' in line and ('+ ' in line or '- ' in line):
                    key_part, value_part = line.split(':', 1)
                    value_part = value_part.strip().rstrip(',')
                    try:
                        calculated_value = safe_eval(value_part)
                        processed_line = key_part + ': ' + str(calculated_value)
                        if line.endswith(','):
                            processed_line += ','
                        processed_lines.append(processed_line)
                    except:
                        processed_lines.append(line)
                else:
                    processed_lines.append(line)

            json_str = '\n'.join(processed_lines)
            result = json.loads(json_str)

            if 'values_change' in result:
                values_change = result['values_change']
                target_keys = ['爱国价值观', '敬业价值观', '诚信价值观', '友善价值观', '思政课获得感']

                for key in target_keys:
                    if key in values_change:
                        current_val = getattr(self.values, key)
                        new_val_from_llm = float(values_change[key])
                        delta_llm = new_val_from_llm - current_val

                        # 动态构建并获取对应价值观的认知惯性因子名称
                        factor_name = f"COGNITIVE_INERTIA_FACTOR_{key}"
                        inertia_factor = getattr(Config, factor_name, 0.002)
                        actual_delta = delta_llm * inertia_factor

                        final_new_val = current_val + actual_delta
                        setattr(self.values, key, np.clip(final_new_val, 1.0, 30.0))

            return float(np.clip(result.get('influence_strength', 0.1), 0, 1))
        except Exception as e:
            print(f"解析LLM响应失败: {e}")
            print(f"原始响应: {response}")
            return 0.0


# ===================================================================
# 具体主体实现
# ===================================================================
class Student(Agent):
    def __init__(self, agent_id: int, profile_data: dict):
        super().__init__(agent_id, AgentType.STUDENT)
        self.raw_data = profile_data.copy()
        self._initialize_from_profile(profile_data)
        self._calculate_influence_factors()

    def _initialize_from_profile(self, data: dict):
        self.values = CoreValues(
            爱国价值观=data.get("爱国价值观", 4.0),
            敬业价值观=data.get("敬业价值观", 4.0),
            诚信价值观=data.get("诚信价值观", 4.0),
            友善价值观=data.get("友善价值观", 4.0),
            思政课获得感=data.get("思政课获得感", 4.0),
            内化问题=data.get("内化问题", 10.0),
            外化问题=data.get("外化问题", 10.0),
            学校归属感=data.get("学校归属感", 4.0),
            施瓦茨价值观_成长=data.get("施瓦茨价值观_成长", 4.0),
            施瓦茨价值观_自我保护=data.get("施瓦茨价值观_自我保护", 4.0),
            施瓦茨价值观_关注社会=data.get("施瓦茨价值观_关注社会", 4.0),
            施瓦茨价值观_关注个人=data.get("施瓦茨价值观_关注个人", 4.0),
            施瓦茨价值观_自我增强=data.get("施瓦茨价值观_自我增强", 4.0),
            施瓦茨价值观_自我超越=data.get("施瓦茨价值观_自我超越", 4.0),
            施瓦茨价值观_开放=data.get("施瓦茨价值观_开放", 4.0),
            施瓦茨价值观_保守=data.get("施瓦茨价值观_保守", 4.0)
        )
        self.personal_politics = data.get("本人政治面貌", 3)
        self.parent_child_relationship = data.get("亲子关系", 4)
        self.internet_usage_hours = data.get("网络活动时长", 3)
        self.party_activities = data.get("参加党团活动", 2)
        self.club_activities = data.get("参加学校社团活动", 2)
        self.father_politics = data.get("父亲政治面貌", 3)
        self.mother_politics = data.get("母亲政治面貌", 3)
        self.father_education = data.get("父母的受教育程度（父亲）", 3)
        self.mother_education = data.get("父母的受教育程度（母亲）", 3)

    def _calculate_influence_factors(self):
        self.peer_sensitivity = np.clip((self.values.学校归属感 / 5.0 * 0.7 + self.club_activities / 5.0 * 0.3), 0.2,
                                        0.95)
        self.media_susceptibility = np.clip(
            (self.internet_usage_hours / 10.0 * 0.5 + self.values.施瓦茨价值观_开放 / 7.0 * 0.5), 0.1, 0.9)
        politics_factor = (4.0 - self.personal_politics) / 3.0
        self.authority_acceptance = np.clip(
            (politics_factor * 0.4 + self.values.思政课获得感 / 5.0 * 0.3 + self.party_activities / 5.0 * 0.3), 0.1,
            0.9)
        parent_politics_avg = (self.father_politics + self.mother_politics) / 2
        parent_education_avg = (self.father_education + self.mother_education) / 2
        parent_politics_factor = (4.0 - parent_politics_avg) / 3.0
        self.family_influence_weight = np.clip((
                self.parent_child_relationship / 5.0 * 0.5 + parent_politics_factor * 0.25 + parent_education_avg / 8.0 * 0.25),
            0.1, 0.8)


class Parent(Agent):
    def __init__(self, agent_id: int, student_data: dict):
        super().__init__(agent_id, AgentType.PARENT)
        core_values_data = {k: v for k, v in student_data.items()
                            if k in ['爱国价值观', '敬业价值观', '诚信价值观', '友善价值观', '思政课获得感']}
        fixed_attrs = {
            '内化问题': 10, '外化问题': 10, '学校归属感': 4, '施瓦茨价值观_成长': 4,
            '施瓦茨价值观_自我保护': 4, '施瓦茨价值观_关注社会': 4, '施瓦茨价值观_关注个人': 4,
            '施瓦茨价值观_自我增强': 4, '施瓦茨价值观_自我超越': 4, '施瓦茨价值观_开放': 4, '施瓦茨价值观_保守': 4
        }
        all_values_data = {**core_values_data, **fixed_attrs}
        self.values = CoreValues(**all_values_data)
        self.influence_strength = 0.4


class Teacher(Agent):
    def __init__(self, agent_id: int, teacher_type: str):
        agent_type_map = {"ideological": AgentType.TEACHER_IDEOLOGICAL, "management": AgentType.TEACHER_MANAGEMENT,
                          "course": AgentType.TEACHER_COURSE}
        super().__init__(agent_id, agent_type_map[teacher_type])
        self.teacher_type = teacher_type
        self.values = CoreValues(
            爱国价值观=4.9, 敬业价值观=4.8, 诚信价值观=4.7, 友善价值观=4.6, 思政课获得感=4.9,
            内化问题=5, 外化问题=5, 学校归属感=4.8, 施瓦茨价值观_成长=5.5,
            施瓦茨价值观_自我保护=4.8, 施瓦茨价值观_关注社会=6.0, 施瓦茨价值观_关注个人=4.2,
            施瓦茨价值观_自我增强=4.5, 施瓦茨价值观_自我超越=5.8, 施瓦茨价值观_开放=5.2,
            施瓦茨价值观_保守=5.5
        )
        self.influence_strength = 0.7 if teacher_type == "ideological" else 0.5


# ===================================================================
# 内容数据库
# ===================================================================
class ContentDatabase:
    def __init__(self):
        base_vals_dict = {
            "爱国价值观": 4.5, "敬业价值观": 4.5, "诚信价值观": 4.5, "友善价值观": 4.5, "思政课获得感": 4.0,
            "内化问题": 10, "外化问题": 10, "学校归属感": 4, "施瓦茨价值观_成长": 4,
            "施瓦茨价值观_自我保护": 4, "施瓦茨价值观_关注社会": 4, "施瓦茨价值观_关注个人": 4,
            "施瓦茨价值观_自我增强": 4, "施瓦茨价值观_自我超越": 4, "施瓦茨价值观_开放": 4,
            "施瓦茨价值观_保守": 4
        }

        # 马克思主义教育
        marxist_vals = base_vals_dict.copy()
        marxist_vals.update({
            "爱国价值观": 5,
            "敬业价值观": 4.3,
            "诚信价值观": 5,
            "思政课获得感": 2.6
        })

        # 竞争性叙事
        competitive_vals = base_vals_dict.copy()
        competitive_vals.update({
            "敬业价值观": 3.75,
            "诚信价值观": 4.8,
            "友善价值观": 3.3
        })

        # 合作性活动
        collaborative_vals = base_vals_dict.copy()
        collaborative_vals.update({
            "友善价值观": 4.9,
            "敬业价值观": 4.2,
            "诚信价值观": 4.5,
            "思政课获得感": 4.1
        })

        # 日常中性内容
        neutral_vals = base_vals_dict.copy()
        neutral_vals.update({
            "敬业价值观": 4.0,
            "诚信价值观": 4.8,
            "友善价值观": 4.15,
            "思政课获得感": 3.5
        })

        # 专业课程指导
        course_guidance_vals = base_vals_dict.copy()
        course_guidance_vals.update({
            "敬业价值观": 4.1,
            "诚信价值观": 4.5,
            "友善价值观": 4.4
        })

        self.contents = {
            ContentType.MARXIST_EDUCATION: [
                ContentItem(ContentType.MARXIST_EDUCATION, "爱国主义教育", "...", CoreValues(**marxist_vals), 0.9,
                            0.5)],
            ContentType.COMPETITIVE_NARRATIVE: [
                ContentItem(ContentType.COMPETITIVE_NARRATIVE, "个人发展与职业规划", "...",
                            CoreValues(**competitive_vals), 0.6, 0.9)],
            ContentType.NEUTRAL_DAILY: [
                ContentItem(ContentType.NEUTRAL_DAILY, "大学生活", "...", CoreValues(**neutral_vals), 0.4, 0.6)],
            ContentType.COLLABORATIVE_ACTIVITY: [
                ContentItem(ContentType.COLLABORATIVE_ACTIVITY, "小组项目与社团活动", "...",
                            CoreValues(**collaborative_vals), 0.5, 0.8)],
            ContentType.COURSE_GUIDANCE: [
                ContentItem(ContentType.COURSE_GUIDANCE, "专业课程学习与指导", "...",
                            CoreValues(**course_guidance_vals), 0.7, 0.7)]
        }

    def get_random_content(self, content_type: ContentType) -> ContentItem:
        return random.choice(self.contents[content_type])


# ===================================================================
# 主模拟器类
# ===================================================================
class YouthValuesSimulator:
    def __init__(self, profile_file_path: str):
        self.client = None
        self.llm_call_count, self.llm_success_count, self.llm_failure_count = 0, 0, 0
        self.profile_data = self.load_profile_data(profile_file_path)
        Config.NUM_STUDENTS = len(self.profile_data)
        Config.NUM_PARENTS = len(self.profile_data)
        if Config.USE_LLM_MODE: self.setup_api()
        self.setup_output_dir()
        self.content_db = ContentDatabase()
        self.agents, self.values_history = {}, {}

    def load_profile_data(self, file_path: str) -> List[dict]:
        print(f"加载群体特征画像数据: {file_path}")
        df = pd.read_csv(file_path, encoding='utf-8-sig')
        return df.to_dict('records')

    def setup_api(self):
        try:
            self.client = OpenAI(api_key=Config.QIANWEN_API_KEY, base_url=Config.QIANWEN_BASE_URL)
            print("千问API初始化成功。")
        except Exception as e:
            print(f"千问API初始化失败: {e}")

    def setup_output_dir(self):
        if not os.path.exists(Config.OUTPUT_DIR): os.makedirs(Config.OUTPUT_DIR)

    def create_agents(self):
        print(f"正在创建 {Config.NUM_STUDENTS} 个学生, {Config.NUM_PARENTS} 个家长, 和 {Config.NUM_TEACHERS} 个教师...")
        for i, data in enumerate(self.profile_data):
            self.agents[f"student_{i}"] = Student(i, data)
            self.agents[f"parent_{i}"] = Parent(Config.NUM_STUDENTS + Config.NUM_TEACHERS + i, data)
        teacher_types = ["ideological", "management", "course"]
        for i, t_type in enumerate(teacher_types):
            self.agents[f"teacher_{i}"] = Teacher(Config.NUM_STUDENTS + i, t_type)
        print(f"智能体创建完成。")

    def run_simulation(self):
        print("=" * 70 + "\n开始运行青少年价值观形成ABM仿真（52周年度仿真）\n" + "=" * 70)
        self.create_agents()
        print("即将开始仿真循环...")
        self.record_weekly_values(0)
        for week in range(1, Config.TOTAL_WEEKS + 1):
            if week % 4 == 0: print(f"第 {week} 周 模拟完成...")
            self.simulate_week(week)
            self.record_weekly_values(week)
        return self._final_analysis()

    def simulate_week(self, week: int):
        for _ in range(Config.IDEOLOGICAL_CLASS_FREQUENCY): self._simulate_ideological_class()
        for _ in range(Config.COURSE_CLASS_FREQUENCY): self._simulate_course_class()
        if week % Config.PARTY_ACTIVITY_INTERVAL == 0: self._simulate_party_activities()
        for _ in range(Config.PEER_INTERACTIONS_PER_WEEK): self._simulate_peer_interactions()
        for _ in range(Config.FAMILY_INTERACTIONS_PER_WEEK): self._simulate_family_interactions()
        for _ in range(Config.MEDIA_EXPOSURES_PER_WEEK): self._simulate_media_exposure()

    def _get_students(self) -> List[Student]:
        return [a for a in self.agents.values() if isinstance(a, Student)]

    def _simulate_ideological_class(self):
        teacher = next((a for a in self.agents.values() if a.agent_type == AgentType.TEACHER_IDEOLOGICAL), None)
        if not teacher: return
        content = self.content_db.get_random_content(ContentType.MARXIST_EDUCATION)
        for student in self._get_students():
            rebellion_factor = np.clip(
                1.0 - (student.values.施瓦茨价值观_开放 / 7.0 - student.authority_acceptance) * 0.5, 0.5, 1.0)
            influence = teacher.influence_strength * student.authority_acceptance * rebellion_factor
            student.update_values(content, influence, self.client, self)
            fatigue_decay = student.values.思政课获得感 * (1.0 - Config.IDEOLOGICAL_CLASS_FATIGUE_FACTOR)
            student.values.思政课获得感 = np.clip(
                student.values.思政课获得感 - fatigue_decay * Config.COGNITIVE_INERTIA_FACTOR_思政课获得感 * 0.8,
                1.0, 30.0
            )

    def _simulate_course_class(self):
        teacher = next((a for a in self.agents.values() if a.agent_type == AgentType.TEACHER_COURSE), None)
        if not teacher: return
        content = self.content_db.get_random_content(ContentType.COURSE_GUIDANCE)
        for student in self._get_students():
            influence = teacher.influence_strength * student.authority_acceptance
            student.update_values(content, influence, self.client, self)

    def _simulate_party_activities(self):
        teacher = next((a for a in self.agents.values() if a.agent_type == AgentType.TEACHER_MANAGEMENT), None)
        if not teacher: return
        content = self.content_db.get_random_content(ContentType.MARXIST_EDUCATION)
        participants = [s for s in self._get_students() if s.authority_acceptance > 0.5 and s.personal_politics < 3]
        for student in participants:
            influence = teacher.influence_strength * student.authority_acceptance
            student.update_values(content, influence, self.client, self)
            form_penalty = student.values.思政课获得感 * Config.FORM_OVER_SUBSTANCE_PENALTY
            student.values.思政课获得感 = np.clip(
                student.values.思政课获得感 - form_penalty * Config.COGNITIVE_INERTIA_FACTOR_思政课获得感 * 0.5,
                1.0, 30.0
            )

    def _simulate_peer_interactions(self):
        students = self._get_students()
        if len(students) < 2: return
        student1, student2 = random.sample(students, 2)
        rand_val = random.random()
        content_type = ContentType.COLLABORATIVE_ACTIVITY if rand_val < 0.4 else (
            ContentType.COMPETITIVE_NARRATIVE if rand_val < 0.7 else ContentType.NEUTRAL_DAILY)
        content = self.content_db.get_random_content(content_type)
        if content_type == ContentType.NEUTRAL_DAILY:
            content.values_orientation = student1.values
        influence = 0.25 * student2.peer_sensitivity
        student2.update_values(content, influence, self.client, self)

    def _simulate_family_interactions(self, intensity: float = 1.0):
        for student in self._get_students():
            parent = self.agents.get(f"parent_{student.agent_id}")
            if parent:
                content = ContentItem(ContentType.NEUTRAL_DAILY, "家庭交流", "...", parent.values, 0.5, 0.4)
                influence = parent.influence_strength * student.family_influence_weight * intensity
                student.update_values(content, influence, self.client, self)

    def _simulate_media_exposure(self, intensity: float = 1.0):
        for student in self._get_students():
            if random.random() < 0.8 * intensity:
                content_type = random.choices(
                    [ContentType.MARXIST_EDUCATION, ContentType.COMPETITIVE_NARRATIVE, ContentType.NEUTRAL_DAILY],
                    weights=[0.20, 0.50, 0.30])[0]
                content = self.content_db.get_random_content(content_type)
                influence = 0.2 * student.media_susceptibility
                student.update_values(content, influence, self.client, self)

    def record_weekly_values(self, week: int):
        self.values_history[week] = {}
        for agent_key, agent in self.agents.items():
            if isinstance(agent, Student):
                self.values_history[week][agent_key] = {
                    '爱国价值观': agent.values.爱国价值观, '敬业价值观': agent.values.敬业价值观,
                    '诚信价值观': agent.values.诚信价值观, '友善价值观': agent.values.友善价值观,
                    '思政课获得感': agent.values.思政课获得感
                }

    def _final_analysis(self) -> Dict[str, float]:
        results = []
        for student in self._get_students():
            initial_values = student.raw_data
            final_values = {
                '爱国价值观': student.values.爱国价值观, '敬业价值观': student.values.敬业价值观,
                '诚信价值观': student.values.诚信价值观, '友善价值观': student.values.友善价值观,
                '思政课获得感': student.values.思政课获得感
            }
            result = {'student_id': student.agent_id}
            for key, final_val in final_values.items():
                initial_val = initial_values.get(key, final_val)
                result[f'change_{key}'] = final_val - initial_val
            results.append(result)

        results_df = pd.DataFrame(results)
        self._save_results(results_df)

        print("\n" + "=" * 70 + "\n仿真结果分析\n" + "=" * 70)
        print(f"LLM总调用次数: {self.llm_call_count}, 成功: {self.llm_success_count}, 失败: {self.llm_failure_count}")

        sim_changes = {}
        target_vars = ["爱国价值观", "敬业价值观", "诚信价值观", "友善价值观", "思政课获得感"]

        # 统计输出五个价值观变化的均值
        print(f"\n{'价值观维度':<20} | {'平均变化值':<15}")
        print("-" * 40)
        for var in target_vars:
            col = f'change_{var}'
            avg_change = results_df[col].mean() if col in results_df.columns else 0
            sim_changes[var] = avg_change
            print(f"{var:<20} | {avg_change:+.4f}")

        return sim_changes

    def _save_results(self, results_df: pd.DataFrame):
        change_cols = ['student_id', 'change_爱国价值观', 'change_敬业价值观', 'change_诚信价值观', 'change_友善价值观',
                       'change_思政课获得感']
        final_df = results_df[[col for col in change_cols if col in results_df.columns]]
        final_df.to_csv(os.path.join(Config.OUTPUT_DIR, "simulation_results_52weeks.csv"), index=False,
                        encoding='utf-8-sig')
        history_records = []
        for week, week_data in self.values_history.items():
            for agent_key, values in week_data.items():
                record = {'week': week, 'agent': agent_key, **values}
                history_records.append(record)
        pd.DataFrame(history_records).to_csv(os.path.join(Config.OUTPUT_DIR, "values_evolution_52weeks.csv"),
                                             index=False, encoding='utf-8-sig')
        print(f"\n详细结果已保存至 '{Config.OUTPUT_DIR}' 文件夹。")


# ===================================================================
# 主程序入口
# ===================================================================
if __name__ == "__main__":
    try:
        profile_file = "群体特征画像.csv"
        if not os.path.exists(profile_file):
            raise FileNotFoundError(f"错误: 找不到画像文件 '{profile_file}'")

        simulator = YouthValuesSimulator(profile_file)
        sim_results = simulator.run_simulation()

        print("\n" + "=" * 70 + "\n青少年价值观模拟完成\n" + "=" * 70)
        if sim_results:
            print("仿真成功完成，各价值观变化均值统计如上所示。")
        else:
            print("仿真过程中出现问题，请检查日志。")

    except Exception as e:
        import traceback

        print(f"\n仿真过程中发生严重错误: {e}")
        traceback.print_exc()