#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score
import warnings
import pickle
import os
from datetime import datetime

warnings.filterwarnings('ignore')

# 固定随机种子确保结果一致性
np.random.seed(42)


class EnhancedGroupChangeAnalyzer:
    def __init__(self):
        # --- 用于聚类的10个核心环境特征 ---
        self.features = [
            '社会阶层',
            '生活地区',
            '父母的受教育程度（母亲）',
            '家庭经济条件',
            '父母教育期望',
            '亲子关系',
            '专业类型',
            '思政课获得感',
            '学校归属感',
            '十大育人'
        ]

        # 该列表将动态填充，以存储所有需要分析变化的字段
        self.all_features_for_analysis = []

        self.scaler = None
        self.model = None
        self.label_encoders = {}  # 存储标签编码器确保一致性

    def load_data(self, data_2023_path, data_2024_path=None):
        """加载数据，并动态获取所有字段用于后续分析"""
        if data_2023_path.endswith('.xlsx'):
            data_2023 = pd.read_excel(data_2023_path, engine='openpyxl')
        else:
            data_2023 = pd.read_csv(data_2023_path, encoding='utf-8-sig')
        print(f"2023年原始数据: {len(data_2023)} 行 × {len(data_2023.columns)} 列")

        # --- 新增: 动态获取所有字段，并排除ID列 ---
        self.all_features_for_analysis = [col for col in data_2023.columns if col != '序号']

        if data_2024_path is None:
            return data_2023, None

        if data_2024_path.endswith('.xlsx'):
            data_2024 = pd.read_excel(data_2024_path, engine='openpyxl')
        else:
            data_2024 = pd.read_csv(data_2024_path, encoding='utf-8-sig')
        print(f"2024年原始数据: {len(data_2024)} 行 × {len(data_2024.columns)} 列")

        common_ids = set(data_2023['序号']) & set(data_2024['序号'])
        matched_2023 = data_2023[data_2023['序号'].isin(common_ids)].sort_values('序号').reset_index(drop=True)
        matched_2024 = data_2024[data_2024['序号'].isin(common_ids)].sort_values('序号').reset_index(drop=True)
        print(f"匹配个体数: {len(common_ids)}")
        return matched_2023, matched_2024

    def preprocess_data(self, data, fit_encoders=True):
        """数据预处理，仅处理用于聚类的特征"""
        processed = pd.DataFrame()
        for feature in self.features:  # 注意：这里只处理聚类特征
            if feature not in data.columns:
                print(f"警告: 特征 '{feature}' 在数据中不存在，将用0填充。")
                processed[feature] = 0
                continue

            numeric_data = pd.to_numeric(data[feature], errors='coerce')

            if numeric_data.notna().sum() / len(data) > 0.8:
                processed[feature] = numeric_data.fillna(numeric_data.median())
            else:
                if fit_encoders:
                    le = LabelEncoder()
                    processed[feature] = le.fit_transform(data[feature].fillna('未知').astype(str))
                    self.label_encoders[feature] = le
                else:
                    if feature in self.label_encoders:
                        le = self.label_encoders[feature]
                        feature_data = data[feature].fillna('未知').astype(str)
                        known_labels = set(le.classes_)
                        encoded_values = [le.transform([val])[0] if val in known_labels else -1 for val in feature_data]
                        processed[feature] = encoded_values
                        if -1 in encoded_values:
                            processed[feature] = processed[feature].replace(-1, 0)
                    else:
                        processed[feature] = 0
        return processed

    def fit_clustering(self, data_2023, k_clusters=30):
        """拟合聚类模型并保存"""
        print(f"开始聚类分析 (k={k_clusters})...")
        processed_2023 = self.preprocess_data(data_2023, fit_encoders=True)
        self.scaler = StandardScaler()
        scaled_2023 = self.scaler.fit_transform(processed_2023)

        self.model = KMeans(n_clusters=k_clusters, random_state=42, n_init=20, max_iter=500, init='k-means++')
        labels_2023 = self.model.fit_predict(scaled_2023)

        silhouette = silhouette_score(scaled_2023, labels_2023)
        calinski = calinski_harabasz_score(scaled_2023, labels_2023)
        print(f"聚类质量评估:\n  轮廓系数: {silhouette:.4f}\n  Calinski-Harabasz指数: {calinski:.2f}")
        print(f"2023年聚类分布: {dict(zip(range(k_clusters), np.bincount(labels_2023)))}")
        return labels_2023, silhouette, calinski

    def save_clustering_model(self, model_path="clustering_model.pkl"):
        """保存聚类模型和预处理器"""
        model_data = {'kmeans_model': self.model, 'scaler': self.scaler, 'label_encoders': self.label_encoders,
                      'features': self.features}
        with open(model_path, 'wb') as f:
            pickle.dump(model_data, f)
        print(f"聚类模型已保存: {model_path}")

    def load_clustering_model(self, model_path="clustering_model.pkl"):
        """加载聚类模型和预处理器"""
        if not os.path.exists(model_path):
            print(f"模型文件不存在: {model_path}")
            return False
        with open(model_path, 'rb') as f:
            model_data = pickle.load(f)
        self.model = model_data['kmeans_model']
        self.scaler = model_data['scaler']
        self.label_encoders = model_data['label_encoders']
        self.features = model_data['features']
        print(f"聚类模型已加载: {model_path}")
        return True

    def generate_cluster_profiles(self, data_2023, labels_2023, output_path="群体特征画像.csv"):
        """生成每个群体的特征画像（包含所有字段）"""
        print("生成群体特征画像...")
        profile_data = data_2023.copy()
        profile_data['群体ID'] = labels_2023

        # --- 修改: 画像包含所有字段 ---
        profile_features = self.all_features_for_analysis

        numeric_profile_data = pd.DataFrame(index=profile_data.index)
        for col in profile_features:
            if col in profile_data.columns:
                numeric_profile_data[col] = pd.to_numeric(profile_data[col], errors='coerce')
        numeric_profile_data['群体ID'] = profile_data['群体ID']

        # 只对数值型数据计算均值
        cluster_profiles = numeric_profile_data.groupby('群体ID').mean()
        cluster_sizes = profile_data.groupby('群体ID').size().to_frame('群体规模')
        final_profiles = pd.concat([cluster_sizes, cluster_profiles], axis=1)
        final_profiles.to_csv(output_path, encoding='utf-8-sig')
        print(f"群体特征画像已保存: {output_path}")
        return final_profiles

    def calculate_all_changes(self, data_2023, data_2024, labels_2023):
        """计算每个群体在所有字段上的变化"""
        results = []
        for i in range(len(data_2023)):
            individual_id = data_2023.iloc[i]['序号']
            cluster_2023 = labels_2023[i]
            individual_2023 = data_2023.iloc[i]
            individual_2024 = data_2024.iloc[i]
            change_record = {'ID': individual_id, 'cluster': cluster_2023}

            # --- 修改: 遍历所有字段，计算其变化 ---
            for feature in self.all_features_for_analysis:
                if feature in data_2023.columns and feature in data_2024.columns:
                    val_2023 = pd.to_numeric(individual_2023.get(feature), errors='coerce')
                    val_2024 = pd.to_numeric(individual_2024.get(feature), errors='coerce')
                    change = val_2024 - val_2023 if pd.notna(val_2023) and pd.notna(val_2024) else np.nan
                    change_record[f'{feature}_2023'] = val_2023
                    change_record[f'{feature}_2024'] = val_2024
                    change_record[f'{feature}_change'] = change
            results.append(change_record)

        individual_changes = pd.DataFrame(results)
        group_changes = {}
        for cluster in sorted(individual_changes['cluster'].unique()):
            cluster_data = individual_changes[individual_changes['cluster'] == cluster]
            group_changes[f'群体{cluster}'] = {'个体数': len(cluster_data)}
            # --- 修改: 计算所有字段的平均变化 ---
            for feature in self.all_features_for_analysis:
                change_col = f'{feature}_change'
                if change_col in cluster_data.columns:
                    avg_change = cluster_data[change_col].mean(skipna=True)
                    group_changes[f'群体{cluster}'][f'{feature}_平均变化'] = round(avg_change, 4) if pd.notna(
                        avg_change) else 0
        return group_changes, individual_changes

    def save_results(self, group_changes, individual_changes, clustered_data_for_report=None):
        """保存所有分析结果"""
        if group_changes:
            # --- 修改: 更新文件名以反映内容 ---
            pd.DataFrame(group_changes).T.to_csv("群体变化量结果.csv", encoding='utf-8-sig')
            print("已保存: 群体变化量结果.csv")
        if individual_changes is not None:
            # --- 修改: 更新文件名以反映内容 ---
            individual_changes.to_csv("个体追踪变化详情.csv", encoding='utf-8-sig', index=False)
            print("已保存: 个体追踪变化详情.csv")

            simple_tracking = individual_changes[['ID', 'cluster']]
            # --- 修改: 包含所有字段的变化量 ---
            change_cols = [f'{f}_change' for f in self.all_features_for_analysis if
                           f'{f}_change' in individual_changes.columns]
            simple_tracking = pd.concat([simple_tracking, individual_changes[change_cols]], axis=1)
            simple_tracking.columns = ['ID', 'cluster'] + [f'{f}_变化量' for f in self.all_features_for_analysis if
                                                           f'{f}_change' in individual_changes.columns]
            simple_tracking.to_csv("个体群体追踪表.csv", encoding='utf-8-sig', index=False)
            print("已保存: 个体群体追踪表.csv")
        self.generate_analysis_report(group_changes, individual_changes, clustered_data_for_report)

    def generate_analysis_report(self, group_changes, individual_changes, clustered_data_for_report=None):
        """生成详细的分析报告"""
        with open("聚类分析报告.txt", "w", encoding='utf-8') as f:
            f.write("=" * 60 + "\n群体聚类与变化分析报告\n" + "=" * 60 + "\n\n")
            f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            if clustered_data_for_report is not None:
                f.write(f"聚类分析概况 (基于2023年环境特征):\n- 数据样本数: {len(clustered_data_for_report):,}\n")
                f.write(
                    f"- 聚类数量: {clustered_data_for_report['群体ID'].nunique()}\n- 聚类特征维度: {len(self.features)}\n\n")
                f.write("各群体规模分布:\n")
                group_sizes = clustered_data_for_report.groupby('群体ID').size().sort_values(ascending=False)
                for group_id, size in group_sizes.items():
                    f.write(f"- 群体{group_id}: {size} 人 ({(size / len(clustered_data_for_report)) * 100:.2f}%)\n")
                f.write("\n")
            if group_changes and individual_changes is not None:
                f.write(
                    f"变化分析概况 (2023 -> 2024):\n- 追踪个体数: {len(individual_changes):,}\n- 分析群体数: {len(group_changes)}\n\n")
                f.write("核心价值观平均变化:\n")
                core_values = ['爱国价值观', '敬业价值观', '诚信价值观', '友善价值观']
                group_df = pd.DataFrame(group_changes).T
                for value in core_values:
                    change_col = f'{value}_平均变化'
                    if change_col in group_df.columns:
                        avg_change = group_df[change_col].mean()
                        f.write(f"- {value}: {avg_change:+.4f}\n")
                f.write("\n")
            # --- 修改: 更新文件说明 ---
            f.write(
                "生成文件说明:\n1. 群体特征画像.csv (包含所有字段的均值画像)\n2. 群体变化量结果.csv (包含所有字段的平均变化)\n3. 个体追踪变化详情.csv (包含所有字段的年度值和变化量)\n4. 个体群体追踪表.csv (简化版，包含所有字段的变化量)\n5. clustering_model.pkl\n6. 聚类分析报告.txt\n")
        print("已保存: 聚类分析报告.txt")

    def run_complete_analysis(self, data_2023_path, data_2024_path, k_clusters=30, load_existing_model=True,
                              model_path="clustering_model.pkl"):
        """运行完整的分析流程"""
        print("=" * 80 + "\n增强版群体聚类与变化分析 (基于环境特征)\n" + "=" * 80)
        model_loaded = False
        if load_existing_model and os.path.exists(model_path):
            choice = input(f"发现已存在的模型文件: {model_path}，是否使用? (y/n, 默认y): ").strip().lower()
            if choice in ['', 'y', 'yes']:
                model_loaded = self.load_clustering_model(model_path)

        print(f"\n1. 加载并匹配数据...")
        data_2023, data_2024 = self.load_data(data_2023_path, data_2024_path)

        if not model_loaded:
            print("\n2. 训练新的聚类模型...")
            labels_2023, _, _ = self.fit_clustering(data_2023, k_clusters)
            self.save_clustering_model(model_path)
        else:
            print("\n2. 使用已加载模型预测2023年群体...")
            # 即使加载模型，也需要预处理数据以获取正确的列
            _ = self.preprocess_data(data_2023, fit_encoders=True)  # Fit encoders to handle all columns
            processed_2023_for_predict = self.preprocess_data(data_2023, fit_encoders=False)

            scaled_2023 = self.scaler.transform(processed_2023_for_predict)
            labels_2023 = self.model.predict(scaled_2023)

        print(f"\n3. 生成群体特征画像...")
        clustered_data_for_report = data_2023.copy()
        clustered_data_for_report['群体ID'] = labels_2023
        self.generate_cluster_profiles(data_2023, labels_2023)

        if data_2024 is not None:
            print(f"\n4. 分析各群体所有字段从2023到2024的变化...")
            # --- 修改: 调用新的函数名 ---
            group_changes, individual_changes = self.calculate_all_changes(data_2023, data_2024, labels_2023)
            print(f"\n5. 保存所有分析结果...")
            self.save_results(group_changes, individual_changes, clustered_data_for_report)
            print(f"\n完整分析完成!")
        else:
            print(f"\n4. 仅处理2023年数据，保存聚类结果和画像...")
            self.save_results(None, None, clustered_data_for_report)
            print(f"\n聚类分析完成!")


if __name__ == "__main__":
    analyzer = EnhancedGroupChangeAnalyzer()
    try:
        analyzer.run_complete_analysis(
            data_2023_path="D:/多平台协作/论文/临时使用/马克思教育+大语言模型+ABM/价值观问卷数据/验证数据/2023.xlsx",
            data_2024_path="D:/多平台协作/论文/临时使用/马克思教育+大语言模型+ABM/价值观问卷数据/验证数据/2024.xlsx",
            k_clusters=30,  # 建议将类别数减少，因为特征也减少了
            load_existing_model=True
        )
        print("\n所有文件生成完成! 请检查当前目录的输出文件。")
    except FileNotFoundError as e:
        print(f"文件未找到错误: {e}\n请仔细检查文件名是否正确，并确保CSV文件与此脚本在同一文件夹内。")
    except Exception as e:
        import traceback

        print(f"分析过程中出现未知错误: {e}")
        traceback.print_exc()
