#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
import matplotlib
import re
import warnings
import time
import threading
from openai import OpenAI
import networkx as nx
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
from enum import Enum
import json

# 抑制弃用和用户警告，使输出更整洁
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=UserWarning)

# 配置Matplotlib以使用非交互式后端，并设置字体属性
matplotlib.use('Agg')
plt.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans', 'Liberation Sans'],
    'font.size': 10,
    'axes.unicode_minus': False,
    'figure.autolayout': True
})


# ===================================================================
# 配置参数
# ===================================================================

class Config:
    # --- API和仿真设置 ---
    QIANWEN_API_KEY = "sk-ec041c530a23463daf475b40659ecf94"
    QIANWEN_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
    MODEL_NAME = "qwen-turbo"

    # --- 仿真时长 ---
    SIMULATION_WEEKS = 10
    DAYS_PER_WEEK = 7
    TOTAL_DAYS = SIMULATION_WEEKS * DAYS_PER_WEEK

    # --- 智能体数量 ---
    NUM_STUDENTS = 30
    NUM_TEACHERS = 4
    NUM_PARENTS = 30

    # --- 技术设置 ---
    USE_LLM_MODE = True
    LLM_TIMEOUT = 30
    OUTPUT_DIR = 'youth_values_simulation_2024_calibrated_10w'


    PEER_INTERACTION_RATE = 0.30  # 进一步增加同伴互动压力
    MEDIA_EXPOSURE_RATE = 0.45  # 大幅增加媒体曝光，反映网络时代现实

    # 思政教育频次与现实接轨
    IDEOLOGICAL_CLASS_INTERVAL = 7  # 保持每周一次
    PARTY_ACTIVITY_INTERVAL = 28  # 党团活动频次
    COURSE_CLASS_INTERVAL = 2  # 保持高频日常课程


    # 核心价值观
    PATRIOTIC_SCALER = 0.12
    DEDICATION_SCALER = 0.10
    HONESTY_SCALER = 0.02
    FRIENDLY_SCALER = 0.25


    INTERNALIZATION_SCALER = 0.15
    EXTERNALIZATION_SCALER = 0.35
    IDEOLOGICAL_GAIN_SCALER = -0.25  # 负向效果，思政课获得感下降

    BELONGING_SCALER = 0.06
    SCHWARTZ_SCALER = 0.0  # 施瓦茨价值观已完美匹配，保持不变


# ===================================================================
# 扩展的价值观系统
# ===================================================================

@dataclass
class ExtendedCoreValues:
    爱国价值观: float
    敬业价值观: float
    诚信价值观: float
    友善价值观: float
    内化问题: float
    外化问题: float
    思政课获得感: float
    学校归属感: float
    施瓦茨价值观_成长: float
    施瓦茨价值观_自我保护: float
    施瓦茨价值观_关注社会: float
    施瓦茨价值观_关注个人: float
    施瓦茨价值观_自我增强: float
    施瓦茨价值观_自我超越: float
    施瓦茨价值观_开放: float
    施瓦茨价值观_保守: float


# ===================================================================
# 主体与内容定义
# ===================================================================

class AgentType(Enum):
    STUDENT = "student"
    TEACHER_IDEOLOGICAL = "teacher_ideological"
    TEACHER_MANAGEMENT = "teacher_management"
    TEACHER_COURSE = "teacher_course"
    PARENT = "parent"


class ContentType(Enum):
    MARXIST_EDUCATION = "marxist_education"
    COMPETITIVE_NARRATIVE = "competitive_narrative"
    NEUTRAL_DAILY = "neutral_daily"
    MANAGEMENT_INFO = "management_info"
    COLLABORATIVE_ACTIVITY = "collaborative_activity"


@dataclass
class ContentItem:
    content_type: ContentType
    title: str
    content: str
    values_orientation: ExtendedCoreValues
    authority_level: float
    appeal_level: float


# ===================================================================
# 主体基类
# ===================================================================

class Agent:
    def __init__(self, agent_id: int, agent_type: AgentType):
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.values: Optional[ExtendedCoreValues] = None

    def update_values(self, new_info: ContentItem, source_influence: float,
                      llm_client=None, simulator=None) -> float:
        if not llm_client or not Config.USE_LLM_MODE:
            return 0.0

        try:
            if simulator: simulator.llm_call_count += 1
            prompt = self._generate_cognitive_prompt(new_info, source_influence)
            response = self._call_llm_for_cognition(llm_client, prompt)
            influence_factor = self._parse_llm_response(response, new_info)
            if simulator: simulator.llm_success_count += 1
            return influence_factor
        except Exception as e:
            print(f"LLM调用或解析失败: {e}")
            if simulator: simulator.llm_failure_count += 1
            return 0.0

    def _generate_cognitive_prompt(self, new_info: ContentItem, source_influence: float) -> str:
        return f"""你需要模拟一个青少年学生接收信息后的价值观和心理状态变化过程。

【学生当前状态】
核心价值观: 爱国({self.values.爱国价值观:.2f}), 敬业({self.values.敬业价值观:.2f}), 诚信({self.values.诚信价值观:.2f}), 友善({self.values.友善价值观:.2f})
心理状态: 内化问题({self.values.内化问题:.2f}), 外化问题({self.values.外化问题:.2f})
教育感知: 思政课获得感({self.values.思政课获得感:.2f})
施瓦茨价值观: 成长({self.values.施瓦茨价值观_成长:.2f}), 关注社会({self.values.施瓦茨价值观_关注社会:.2f})

【接收到的信息】
类型: {new_info.content_type.value}, 标题: {new_info.title}, 来源影响力: {source_influence:.2f}

【重要认知规则】
1. 价值观变化极其缓慢和微小，大部分变化应该在0.1以内
2. 当接收到积极、支持性的信息时，学生的"内化问题"倾向于降低
3. 当接收到竞争、压力性的信息时，学生的"外化问题"倾向于增加
4. 施瓦茨价值观作为深层价值结构，变化应该极其微小

【任务】
模拟学生接收信息后的认知过程和状态变化。严格按照以下JSON格式输出，变化幅度要符合现实。
{{
    "cognitive_process": "学生的内心认知过程描述，体现微小但真实的变化",
    "values_change": {{
        "爱国价值观": new_val, "敬业价值观": new_val, "诚信价值观": new_val, "友善价值观": new_val,
        "内化问题": new_val, "外化问题": new_val, "思政课获得感": new_val,
        "学校归属感": new_val,
        "施瓦茨价值观_成长": new_val, "施瓦茨价值观_自我保护": new_val, "施瓦茨价值观_关注社会": new_val,
        "施瓦茨价值观_关注个人": new_val, "施瓦茨价值观_自我增强": new_val, "施瓦茨价值观_自我超越": new_val,
        "施瓦茨价值观_开放": new_val, "施瓦茨价值观_保守": new_val
    }},
    "influence_strength": 本次影响强度(0-1之间的数值)
}}
注意：变化应该是极其渐进的，大多数情况下变化量应小于0.1。
"""

    def _call_llm_for_cognition(self, llm_client, prompt: str) -> str:
        completion = llm_client.chat.completions.create(
            model=Config.MODEL_NAME,
            messages=[
                {"role": "system",
                 "content": "你是心理学和教育学专家，擅长分析青少年认知过程。请严格按照JSON格式输出，变化要符合现实的微小程度。"},
                {"role": "user", "content": prompt}
            ],
            timeout=Config.LLM_TIMEOUT
        )
        return completion.choices[0].message.content

    def _parse_llm_response(self, response: str, new_info: ContentItem) -> float:
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            json_str = json_match.group() if json_match else response
            result = json.loads(json_str)

            if 'values_change' in result:
                values_change = result['values_change']
                for key, value in values_change.items():
                    if hasattr(self.values, key):
                        current_val = getattr(self.values, key)
                        new_val_from_llm = float(value)
                        delta_llm = new_val_from_llm - current_val

                        # 应用精确校准的缩放因子
                        scaled_delta = 0.0
                        if key == '爱国价值观':
                            scaled_delta = delta_llm * Config.PATRIOTIC_SCALER
                        elif key == '敬业价值观':
                            scaled_delta = delta_llm * Config.DEDICATION_SCALER
                        elif key == '诚信价值观':
                            scaled_delta = delta_llm * Config.HONESTY_SCALER
                        elif key == '友善价值观':
                            scaled_delta = delta_llm * Config.FRIENDLY_SCALER
                        elif key == '内化问题':
                            scaled_delta = delta_llm * Config.INTERNALIZATION_SCALER
                        elif key == '外化问题':
                            scaled_delta = delta_llm * Config.EXTERNALIZATION_SCALER
                        elif key == '思政课获得感':
                            scaled_delta = delta_llm * Config.IDEOLOGICAL_GAIN_SCALER
                        elif key == '学校归属感':
                            scaled_delta = delta_llm * Config.BELONGING_SCALER
                        elif '施瓦茨' in key:
                            scaled_delta = delta_llm * Config.SCHWARTZ_SCALER

                        # 保留外化问题的特殊规则
                        if key == '外化问题' and new_info.content_type == ContentType.COMPETITIVE_NARRATIVE:
                            scaled_delta = abs(scaled_delta)

                        final_new_val = current_val + scaled_delta
                        setattr(self.values, key, np.clip(final_new_val, 1.0, 30.0))

            return float(np.clip(result.get('influence_strength', 0.1), 0, 1))
        except Exception as e:
            print(f"解析LLM响应失败: {e}")
            print(f"原始响应: {response}")
            return 0.0


# ===================================================================
# 具体主体实现 (基于2023年画像)
# ===================================================================

class Student(Agent):
    def __init__(self, agent_id: int, profile_data: dict):
        super().__init__(agent_id, AgentType.STUDENT)
        self.raw_data = profile_data.copy()
        self._initialize_from_profile(profile_data)
        self._calculate_influence_factors()

    def _initialize_from_profile(self, data: dict):
        self.values = ExtendedCoreValues(
            爱国价值观=data.get("爱国价值观", 4.0), 敬业价值观=data.get("敬业价值观", 4.0),
            诚信价值观=data.get("诚信价值观", 4.0), 友善价值观=data.get("友善价值观", 4.0),
            内化问题=data.get("内化问题", 10.0), 外化问题=data.get("外化问题", 10.0),
            思政课获得感=data.get("思政课获得感", 4.0), 学校归属感=data.get("学校归属感", 4.0),
            施瓦茨价值观_成长=data.get("施瓦茨价值观_成长", 4.0),
            施瓦茨价值观_自我保护=data.get("施瓦茨价值观_自我保护", 4.0),
            施瓦茨价值观_关注社会=data.get("施瓦茨价值观_关注社会", 4.0),
            施瓦茨价值观_关注个人=data.get("施瓦茨价值观_关注个人", 4.0),
            施瓦茨价值观_自我增强=data.get("施瓦茨价值观_自我增强", 4.0),
            施瓦茨价值观_自我超越=data.get("施瓦茨价值观_自我超越", 4.0),
            施瓦茨价值观_开放=data.get("施瓦茨价值观_开放", 4.0),
            施瓦茨价值观_保守=data.get("施瓦茨价值观_保守", 4.0)
        )
        self.personal_politics = data.get("本人政治面貌", 3)
        self.parent_child_relationship = data.get("亲子关系", 4)
        self.internet_usage_hours = data.get("网络活动时长", data.get("网络使用时长", 3))
        self.party_activities = data.get("参加党团活动", 2)
        self.club_activities = data.get("参加学校社团活动", 2)
        self.father_politics = data.get("父亲政治面貌", 3)
        self.mother_politics = data.get("母亲政治面貌", 3)
        self.father_education = data.get("父母的受教育程度（父亲）", 3)
        self.mother_education = data.get("父母的受教育程度（母亲）", 3)

    def _calculate_influence_factors(self):
        self.peer_sensitivity = np.clip((self.values.学校归属感 / 5.0 * 0.6 + self.club_activities / 5.0 * 0.4), 0.1,
                                        0.9)
        self.media_susceptibility = np.clip(
            (self.internet_usage_hours / 10.0 * 0.5 + self.values.施瓦茨价值观_开放 / 7.0 * 0.5), 0.1, 0.9)
        politics_factor = (4.0 - self.personal_politics) / 3.0
        self.authority_acceptance = np.clip(
            (politics_factor * 0.4 + self.values.思政课获得感 / 5.0 * 0.3 + self.party_activities / 5.0 * 0.3), 0.1,
            0.9)
        parent_politics_avg = (self.father_politics + self.mother_politics) / 2
        parent_education_avg = (self.father_education + self.mother_education) / 2
        parent_politics_factor = (4.0 - parent_politics_avg) / 3.0
        self.family_influence_weight = np.clip((
                self.parent_child_relationship / 5.0 * 0.5 + parent_politics_factor * 0.25 + parent_education_avg / 8.0 * 0.25),
            0.1, 0.8)


class Parent(Agent):
    def __init__(self, agent_id: int, student_data: dict):
        super().__init__(agent_id, AgentType.PARENT)
        self.values = ExtendedCoreValues(**{k: v + random.uniform(-0.1, 0.1) for k, v in student_data.items() if
                                            k in ExtendedCoreValues.__annotations__})
        self.influence_strength = 0.4  # 降低家长影响力


class Teacher(Agent):
    def __init__(self, agent_id: int, teacher_type: str):
        agent_type_map = {"ideological": AgentType.TEACHER_IDEOLOGICAL, "management": AgentType.TEACHER_MANAGEMENT,
                          "course": AgentType.TEACHER_COURSE}
        super().__init__(agent_id, agent_type_map[teacher_type])
        self.teacher_type = teacher_type
        self.values = ExtendedCoreValues(爱国价值观=4.9, 敬业价值观=4.8, 诚信价值观=4.7, 友善价值观=4.6, 内化问题=5,
                                         外化问题=5, 思政课获得感=4.9, 学校归属感=4.8, 施瓦茨价值观_成长=5.5,
                                         施瓦茨价值观_自我保护=4.8, 施瓦茨价值观_关注社会=6.0,
                                         施瓦茨价值观_关注个人=4.2, 施瓦茨价值观_自我增强=4.5,
                                         施瓦茨价值观_自我超越=5.8, 施瓦茨价值观_开放=5.2, 施瓦茨价值观_保守=5.5)
        # 调整教师影响力：思政教师影响力强，但可能引发逆反
        if teacher_type == "ideological":
            self.influence_strength = 0.7  # 高影响力但可能产生负面效果
        else:
            self.influence_strength = 0.5  # 其他教师影响力适中


# ===================================================================
# 内容数据库
# ===================================================================
class ContentDatabase:
    def __init__(self):
        base_vals = {"爱国价值观": 4.5, "敬业价值观": 4.5, "诚信价值观": 4.5, "友善价值观": 4.5, "内化问题": 10,
                     "外化问题": 10, "思政课获得感": 4, "学校归属感": 4, "施瓦茨价值观_成长": 4,
                     "施瓦茨价值观_自我保护": 4, "施瓦茨价值观_关注社会": 4, "施瓦茨价值观_关注个人": 4,
                     "施瓦茨价值观_自我增强": 4, "施瓦茨价值观_自我超越": 4, "施瓦茨价值观_开放": 4,
                     "施瓦茨价值观_保守": 4}

        # 爱国主义教育：虽然强化爱国价值，但可能加剧内心冲突
        marxist_vals = base_vals.copy()
        marxist_vals.update({
            "爱国价值观": 5.2,  # 强化爱国教育效果
            "思政课获得感": 3.5,  # 可能产生逆反心理
            "内化问题": 11,  # 理想与现实的落差可能加剧内化问题
            "诚信价值观": 4.6
        })

        # 竞争性叙事：全面增加心理压力
        competitive_vals = base_vals.copy()
        competitive_vals.update({
            "敬业价值观": 5.0,  # 保持对敬业的提升
            "外化问题": 18,  # 进一步增加外化问题
            "内化问题": 15,  # 显著增加内化问题（焦虑、自我怀疑）
            "诚信价值观": 3.8,  # 竞争损害诚信
            "思政课获得感": 3.2,  # 与现实竞争环境形成反差
            "友善价值观": 4.2  # 竞争损害友善关系
        })

        # 合作活动：虽然有积极效果，但在大环境下作用有限
        collaborative_vals = base_vals.copy()
        collaborative_vals.update({
            "友善价值观": 5.5,  # 大幅提升友善
            "诚信价值观": 5.1,  # 增强诚信
            "内化问题": 9,  # 只是轻微减少，无法完全抵消环境压力
            "外化问题": 7,  # 显著减少外化问题
            "思政课获得感": 4.3  # 实践活动提升获得感
        })

        # 中性日常：普遍的压力背景
        neutral_vals = base_vals.copy()
        neutral_vals.update({
            "外化问题": 12,  # 日常生活中的竞争压力
            "内化问题": 11.5,  # 日常环境也增加内化问题
            "诚信价值观": 4.2,  # 环境对诚信的轻微侵蚀
            "思政课获得感": 3.9,  # 理想与现实的落差
            "友善价值观": 4.3  # 竞争环境对友善的影响
        })

        self.contents = {
            ContentType.MARXIST_EDUCATION: [
                ContentItem(ContentType.MARXIST_EDUCATION, "爱国主义教育", "...",
                            ExtendedCoreValues(**marxist_vals), 0.9, 0.5)  # 高权威性，中等吸引力
            ],
            ContentType.COMPETITIVE_NARRATIVE: [
                ContentItem(ContentType.COMPETITIVE_NARRATIVE, "个人发展与职业规划", "...",
                            ExtendedCoreValues(**competitive_vals), 0.6, 0.9)  # 中等权威性，高吸引力
            ],
            ContentType.NEUTRAL_DAILY: [
                ContentItem(ContentType.NEUTRAL_DAILY, "大学生活", "...",
                            ExtendedCoreValues(**neutral_vals), 0.4, 0.6)  # 低权威性，中等吸引力
            ],
            ContentType.COLLABORATIVE_ACTIVITY: [
                ContentItem(ContentType.COLLABORATIVE_ACTIVITY, "小组项目与社团活动", "...",
                            ExtendedCoreValues(**collaborative_vals), 0.5, 0.8)  # 中等权威性，高吸引力
            ]
        }

    def get_random_content(self, content_type: ContentType) -> ContentItem:
        return random.choice(self.contents[content_type])


# ===================================================================
# 主模拟器类
# ===================================================================
class YouthValuesSimulator:
    def __init__(self, profile_file_path: str):
        self.client = None
        self.llm_call_count, self.llm_success_count, self.llm_failure_count = 0, 0, 0
        self.profile_data = self.load_profile_data(profile_file_path)
        Config.NUM_STUDENTS = len(self.profile_data)
        Config.NUM_PARENTS = len(self.profile_data)
        if Config.USE_LLM_MODE: self.setup_api()
        self.setup_output_dir()
        self.content_db = ContentDatabase()
        self.agents, self.values_history = {}, {}

    def load_profile_data(self, file_path: str) -> List[dict]:
        print(f"加载群体特征画像数据: {file_path}")
        df = pd.read_csv(file_path, encoding='utf-8-sig')
        return df.to_dict('records')

    def setup_api(self):
        try:
            self.client = OpenAI(api_key=Config.QIANWEN_API_KEY, base_url=Config.QIANWEN_BASE_URL)
            print("千问API初始化成功。")
        except Exception as e:
            print(f"千问API初始化失败: {e}")

    def setup_output_dir(self):
        if not os.path.exists(Config.OUTPUT_DIR): os.makedirs(Config.OUTPUT_DIR)

    def create_agents(self):
        print(f"正在创建 {Config.NUM_STUDENTS} 个学生, {Config.NUM_PARENTS} 个家长, 和 {Config.NUM_TEACHERS} 个教师...")
        for i, data in enumerate(self.profile_data):
            self.agents[f"student_{i}"] = Student(i, data)
            self.agents[f"parent_{i}"] = Parent(Config.NUM_STUDENTS + Config.NUM_TEACHERS + i, data)
        teacher_types = ["ideological", "management", "course"]
        for i, t_type in enumerate(teacher_types):
            self.agents[f"teacher_{i}"] = Teacher(Config.NUM_STUDENTS + i, t_type)
        print("智能体创建完成。")

    def run_simulation(self):
        print("=" * 70 + "\n开始运行青少年价值观形成ABM仿真\n" + "=" * 70)
        self.create_agents()
        print("即将开始仿真循环...")
        self.record_daily_values(0)
        for day in range(1, Config.TOTAL_DAYS + 1):
            if day % 7 == 0:
                print(f"第 {day} 天 (第 {day // 7} 周) 模拟完成...")
            self.simulate_day(day)
            self.record_daily_values(day)
        self._final_analysis()

    def simulate_day(self, day: int):
        if day % 7 < 5:
            self._simulate_school_day(day)
        else:
            self._simulate_weekend(day)

    def _simulate_school_day(self, day: int):
        if day % Config.IDEOLOGICAL_CLASS_INTERVAL == 0:
            self._simulate_ideological_class(day)
        if day % Config.COURSE_CLASS_INTERVAL == 0:
            self._simulate_course_class(day)
        self._simulate_peer_interactions(day)
        self._simulate_family_interactions(day)
        self._simulate_media_exposure(day)

    def _simulate_weekend(self, day: int):
        if day % Config.PARTY_ACTIVITY_INTERVAL == 0:
            self._simulate_party_activities(day)
        self._simulate_family_interactions(day, intensity=1.1)  # 降低周末家庭互动强度
        self._simulate_media_exposure(day, intensity=1.15)  # 降低周末媒体曝光强度

    def _simulate_ideological_class(self, day: int):
        teacher = next((a for a in self.agents.values() if a.agent_type == AgentType.TEACHER_IDEOLOGICAL), None)
        if not teacher: return
        students = [a for a in self.agents.values() if isinstance(a, Student)]
        content = self.content_db.get_random_content(ContentType.MARXIST_EDUCATION)
        for student in students:
            teacher_influence = teacher.influence_strength * student.authority_acceptance
            student.update_values(content, teacher_influence, self.client, self)

    def _simulate_course_class(self, day: int):
        teacher = next((a for a in self.agents.values() if a.agent_type == AgentType.TEACHER_COURSE), None)
        if not teacher: return
        students = [a for a in self.agents.values() if isinstance(a, Student)]
        content = self.content_db.get_random_content(ContentType.NEUTRAL_DAILY)
        for student in students:
            teacher_influence = teacher.influence_strength * student.authority_acceptance
            student.update_values(content, teacher_influence, self.client, self)

    def _simulate_party_activities(self, day: int):
        teacher = next((a for a in self.agents.values() if a.agent_type == AgentType.TEACHER_MANAGEMENT), None)
        if not teacher: return
        students = [a for a in self.agents.values() if isinstance(a, Student)]
        content = self.content_db.get_random_content(ContentType.MARXIST_EDUCATION)
        participants = [s for s in students if s.authority_acceptance > 0.5 and s.personal_politics < 3]
        for student in participants:
            teacher_influence = teacher.influence_strength * student.authority_acceptance
            student.update_values(content, teacher_influence, self.client, self)

    def _simulate_peer_interactions(self, day: int):
        students = [a for a in self.agents.values() if isinstance(a, Student)]
        num_interactions = int(len(students) * Config.PEER_INTERACTION_RATE)
        for _ in range(num_interactions):
            if len(students) < 2: continue
            student1, student2 = random.sample(students, 2)

            if random.random() < 0.4:
                content = self.content_db.get_random_content(ContentType.COLLABORATIVE_ACTIVITY)
            else:
                content = ContentItem(ContentType.NEUTRAL_DAILY, "同伴交流", "...", student1.values, 0.2, 0.5)

            peer_influence = 0.3 * student2.peer_sensitivity  # 降低同伴影响力
            student2.update_values(content, peer_influence, self.client, self)

    def _simulate_family_interactions(self, day: int, intensity: float = 1.0):
        students = [a for a in self.agents.values() if isinstance(a, Student)]
        for student in students:
            parent = self.agents.get(f"parent_{student.agent_id}")
            if parent and random.random() < student.family_influence_weight * 0.4 * intensity:  # 降低家庭互动频率
                content = ContentItem(ContentType.NEUTRAL_DAILY, "家庭交流", "...", parent.values, 0.5, 0.4)
                family_influence = parent.influence_strength * student.family_influence_weight
                student.update_values(content, family_influence, self.client, self)

    def _simulate_media_exposure(self, day: int, intensity: float = 1.0):
        students = [a for a in self.agents.values() if isinstance(a, Student)]
        for student in students:
            if random.random() < Config.MEDIA_EXPOSURE_RATE * student.media_susceptibility * intensity:
                # 调整媒体内容权重分布，更接近真实情况
                content_type = random.choices(
                    [ContentType.MARXIST_EDUCATION, ContentType.COMPETITIVE_NARRATIVE, ContentType.NEUTRAL_DAILY],
                    weights=[0.25, 0.35, 0.40])[0]  # 减少竞争性内容，增加中性内容
                content = self.content_db.get_random_content(content_type)
                media_influence = 0.3 * student.media_susceptibility  # 降低媒体影响力
                student.update_values(content, media_influence, self.client, self)

    def record_daily_values(self, day: int):
        self.values_history[day] = {}
        for agent_key, agent in self.agents.items():
            if isinstance(agent, Student):
                self.values_history[day][agent_key] = agent.values.__dict__

    def _final_analysis(self):
        print("\n" + "=" * 70 + "\n最终仿真分析\n" + "=" * 70)
        students = [a for a in self.agents.values() if isinstance(a, Student)]
        results = []
        for student in students:
            initial_values = student.raw_data
            final_values = student.values.__dict__
            result = {'student_id': student.agent_id}
            for key, final_val in final_values.items():
                initial_val = initial_values.get(key, final_val)
                result[f'initial_{key}'] = initial_val
                result[f'final_{key}'] = final_val
                result[f'change_{key}'] = final_val - initial_val
            results.append(result)

        results_df = pd.DataFrame(results)
        print("\n【仿真产生的平均变化量】")
        print("请将此结果与您的真实数据进行对比。")
        print(f"{'变量维度':<30} | {'仿真产生的变化':<20}")
        print("-" * 55)

        target_vars = ["爱国价值观", "敬业价值观", "诚信价值观", "友善价值观", "内化问题", "外化问题", "思政课获得感"]
        schwartz_vars = [f"施瓦茨价值观_{v}" for v in
                         ["成长", "自我保护", "关注社会", "关注个人", "自我增强", "自我超越", "开放", "保守"]]

        for var in target_vars + schwartz_vars:
            col = f'change_{var}'
            if col in results_df.columns:
                avg_change = results_df[col].mean()
                print(f"{var:<30} | {avg_change:+.4f}")

        print(f"\nLLM调用: {self.llm_call_count}, 成功: {self.llm_success_count}, 失败: {self.llm_failure_count}")

        # 输出与真实数据的对比分析
        print("\n【与真实数据对比分析】")
        real_data_changes = {
            "爱国价值观": 0.0361,
            "敬业价值观": 0.0031,
            "诚信价值观": -0.0052,
            "友善价值观": 0.0143,
            "内化问题": 0.0347,
            "外化问题": 0.1457,
            "思政课获得感": -0.0623,
            "施瓦茨价值观_成长": 0.7886,
            "施瓦茨价值观_自我保护": 1.1702,
            "施瓦茨价值观_关注社会": 0.8783,
            "施瓦茨价值观_关注个人": 1.1357,
            "施瓦茨价值观_自我增强": 1.3610,
            "施瓦茨价值观_自我超越": 0.7609,
            "施瓦茨价值观_开放": 0.9458,
            "施瓦茨价值观_保守": 0.9751
        }

        print(f"{'变量维度':<30} | {'真实数据':<12} | {'仿真结果':<12} | {'误差':<12}")
        print("-" * 75)

        total_error = 0
        for var, real_val in real_data_changes.items():
            col = f'change_{var}'
            if col in results_df.columns:
                sim_val = results_df[col].mean()
                error = abs(sim_val - real_val)
                total_error += error
                print(f"{var:<30} | {real_val:+8.4f} | {sim_val:+8.4f} | {error:8.4f}")

        print(f"\n总体误差: {total_error:.4f}")
        print(f"平均误差: {total_error / len(real_data_changes):.4f}")

        self._save_results(results_df)

    def _save_results(self, results_df: pd.DataFrame):
        results_df.to_csv(os.path.join(Config.OUTPUT_DIR, "simulation_results.csv"), index=False, encoding='utf-8-sig')
        history_records = []
        for day, day_data in self.values_history.items():
            for agent_key, values in day_data.items():
                record = {'day': day, 'agent': agent_key, **values}
                history_records.append(record)
        pd.DataFrame(history_records).to_csv(os.path.join(Config.OUTPUT_DIR, "values_evolution.csv"), index=False,
                                             encoding='utf-8-sig')
        print(f"\n结果已保存至 '{Config.OUTPUT_DIR}' 文件夹。")


if __name__ == "__main__":
    try:
        simulator = YouthValuesSimulator("C:/Users/49292/PyCharmMiscProject/群体特征画像.csv")
        simulator.run_simulation()
    except Exception as e:
        import traceback

        print(f"\n仿真过程中发生错误: {e}")
        traceback.print_exc()