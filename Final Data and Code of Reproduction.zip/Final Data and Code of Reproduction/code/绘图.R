library(ggplot2)
library(dplyr)
library(tidyr)
library(readr)
library(stringr)
library(patchwork)
library(scales)
library(grid)


setwd("D:/多平台协作/论文/临时使用/马克思教育+大语言模型+ABM/绘图")#笔记本
##############################4.1
library(tidyverse)
library(ggrepel)
library(patchwork)

# ==============================================================================
# 1. 数据准备
# ==============================================================================
df <- read_csv("sim data dynamic.csv") # 假设数据已加载

df_clean <- df %>%
  filter(group == 1) %>% 
  rename(Week = week, Agent = agent, Friendliness = Kindness, CourseGain = CourseGains) %>%
  select(Week, Agent, Patriotism, Dedication, Integrity, Friendliness, CourseGain) %>%
  pivot_longer(cols = c("Patriotism", "Dedication", "Integrity", "Friendliness", "CourseGain"), 
               names_to = "ValueType", 
               values_to = "Value")

df_change <- df_clean %>%
  group_by(Agent, ValueType) %>%
  mutate(
    Start_Value = first(Value[Week == 0]),
    Change_Value = Value - Start_Value
  ) %>%
  ungroup()

# 定义子图标题映射
target_types <- c(
  "Patriotism"   = "a. Patriotism",
  "Dedication"   = "b. Dedication",
  "Integrity"    = "c. Integrity",
  "Friendliness" = "d. Friendliness",
  "CourseGain"   = "e. CourseGain"
)

# ==============================================================================
# 2. 核心：绘图函数 (支持错峰标注)
# ==============================================================================
create_subplot <- function(v_type, display_name) {
  
  # --- 2.1 数据筛选 ---
  current_data <- df_change %>% filter(ValueType == v_type)
  
  # --- 2.2 定义状态 (基于 Week 52 的排名) ---
  final_stats <- current_data %>%
    filter(Week == 52) %>%
    mutate(
      Rank_Asc = rank(Change_Value),           # 升序排名 (1是最小)
      Rank_Desc = rank(-Change_Value),         # 降序排名 (1是最大)
      Status = case_when(
        Rank_Desc == 1 ~ "Top 1",              # 第一名
        Rank_Desc == 2 ~ "Top 2",              # 第二名
        Rank_Asc == 1 ~ "Bottom 1",            # 倒数第一
        Rank_Asc == 2 ~ "Bottom 2",            # 倒数第二
        TRUE ~ "Background"
      )
    ) %>%
    select(Agent, Status)
  
  # 合并状态回主数据
  plot_data <- current_data %>% left_join(final_stats, by = "Agent")
  
  # 计算均值线
  mean_data <- plot_data %>%
    group_by(Week) %>%
    summarise(Change_Value = mean(Change_Value), .groups = 'drop') %>%
    mutate(Agent = "Group Mean", Status = "Mean")
  
  # --- 2.3 构造“错峰”标签数据 (Staggered Labels) ---
  # 策略：
  # Top 1 / Bottom 1 -> 标在 Week 52 (终点)
  # Top 2 / Bottom 2 -> 标在 Week 38 (错开)
  # Mean             -> 标在 Week 20 (早期)
  
  # A. 提取需要标注的 Agent 在特定 Week 的数据
  target_labels <- plot_data %>%
    filter(Status != "Background") %>%
    mutate(
      Target_Week = case_when(
        Status %in% c("Top 1", "Bottom 1") ~ 52,
        Status %in% c("Top 2", "Bottom 2") ~ 38, # 第二梯队提前标
        TRUE ~ 52
      )
    ) %>%
    filter(Week == Target_Week) # 只保留目标周的那一行
  
  # B. 提取均值线在特定 Week 的数据
  mean_label <- mean_data %>%
    filter(Week == 20) # 均值线在前面标
  
  # C. 合并并格式化文本
  final_labels <- bind_rows(target_labels, mean_label) %>%
    mutate(
      Label_Text = paste0(Agent, "\n(", sprintf("%+.2f", Change_Value), ")"),
      # 统一颜色映射组
      Color_Group = case_when(
        grepl("Top", Status) ~ "Top",
        grepl("Bottom", Status) ~ "Bottom",
        Status == "Mean" ~ "Mean",
        TRUE ~ "Background"
      )
    )
  
  # --- 2.4 配色与绘图参数 ---
  # 注意：Status 列现在区分了 Top 1/2，绘图时要映射回统一的 Top/Bottom 颜色
  # 我们可以增加一列用于绘图的 Group
  plot_data <- plot_data %>%
    mutate(Plot_Group = case_when(
      grepl("Top", Status) ~ "Top",
      grepl("Bottom", Status) ~ "Bottom",
      TRUE ~ "Background"
    ))
  
  sci_colors <- c("Top" = "#C0392B", "Bottom" = "#2980B9", "Mean" = "black", "Background" = "#B0B0B0")
  
  # --- 2.5 绘图 ---
  p <- ggplot() +
    # 背景线
    stat_smooth(data = subset(plot_data, Plot_Group == "Background"),
                aes(x = Week, y = Change_Value, group = Agent),
                geom = "line", method = "loess", span = 0.15, se = FALSE,
                color = sci_colors["Background"], size = 0.3, alpha = 0.4) +
    
    # 均值线
    stat_smooth(data = mean_data,
                aes(x = Week, y = Change_Value),
                geom = "line", method = "loess", span = 0.15, se = FALSE,
                color = "black", linetype = "dashed", size = 0.7, alpha = 0.8) +
    
    # 高亮线
    stat_smooth(data = subset(plot_data, Plot_Group != "Background"),
                aes(x = Week, y = Change_Value, group = Agent, color = Plot_Group),
                geom = "line", method = "loess", span = 0.15, se = FALSE,
                size = 0.9) +
    
    # 错峰标签 (Staggered Labels)
    geom_text_repel(
      data = final_labels,
      aes(x = Week, y = Change_Value, label = Label_Text, color = Color_Group),
      
      # 智能布局参数
      direction = "y",           # 主要上下避让，因为x轴已经手动错开了
      nudge_y = 0.1,             # 稍微把字往上/下推一点，不压线
      box.padding = 0.5,         # 增加文字框周围的留白
      
      size = 2.6,
      fontface = "bold",
      bg.color = "white",        # 白边
      bg.r = 0.15,
      segment.size = 0.3,
      segment.color = "gray50",
      show.legend = FALSE
    ) +
    
    # 辅助元素
    geom_hline(yintercept = 0, linetype = "solid", color = "black", size = 0.3, alpha = 0.5) +
    
    scale_color_manual(values = sci_colors) +
    scale_x_continuous(limits = c(0, 55), breaks = seq(0, 52, 10)) + # 稍微留点余地
    
    labs(
      title = display_name,
      x = "Simulation Week",
      y = "Cumulative Change"
    ) +
    
    theme_classic(base_size = 10) +
    theme(
      legend.position = c(0.12, 0.92), # 图例在左上角
      legend.background = element_rect(fill = alpha("white", 0.8), color = NA),
      legend.key.height = unit(0.3, "cm"),
      legend.key.width = unit(0.4, "cm"), # 图例紧凑一点
      legend.text = element_text(size = 8),
      legend.title = element_blank(),
      
      axis.line = element_line(color = "black", size = 0.5),
      plot.title = element_text(size = 11, hjust = 0),
      plot.margin = margin(5, 5, 5, 5)
    )
  
  return(p)
}

# ==============================================================================
# 3. 批量生成 & 拼接
# ==============================================================================
plot_list <- list()

# 循环生成
for (v_type in names(target_types)) {
  plot_list[[v_type]] <- create_subplot(v_type, target_types[v_type])
}

# 拼接 (垂直排列)
final_plot <- wrap_plots(plot_list, ncol = 1)

# 显示
final_plot
  




###########################4.2
###########################4.2
###########################4.2
library(ggplot2)
library(dplyr)
library(tidyr)
library(readr)
library(stringr)
library(patchwork)
library(scales)
  


# ==============================================================================
# 1. (Data Preparation)
# ==============================================================================
file_name <- "时序数据整理.csv"
df <- read_csv(file_name, show_col_types = FALSE)

term_mapping <- c(
  "爱国价值观" = "Patriotism", "Patriotism" = "Patriotism",
  "敬业价值观" = "Dedication", "Dedication" = "Dedication",
  "诚信价值观" = "Integrity",  "Integrity"  = "Integrity",
  "友善价值观" = "Kindness",   "Friendliness" = "Kindness", "kindness" = "Kindness", "Kindness" = "Kindness",
  "思政课获得感" = "CourseGain", "CourseGain" = "CourseGain", "CourseGains" = "CourseGain"
)

df_clean <- df %>%
  rename(
    Initial_Col = initial, Level = value, Week = week, Agent = agent,
    Patriotism = any_of(c("爱国价值观", "Patriotism")),
    Dedication = any_of(c("敬业价值观", "Dedication")),
    Integrity  = any_of(c("诚信价值观", "Integrity")),
    Kindness   = any_of(c("友善价值观", "Friendliness", "kindness", "Kindness")),
    CourseGain = any_of(c("思政课获得感", "CourseGain", "CourseGains"))
  )

       
df_clean$Initial_Var <- term_mapping[df_clean$Initial_Col]


value_cols <- c("Patriotism", "Dedication", "Integrity", "Kindness", "CourseGain")
df_long <- df_clean %>%
  pivot_longer(cols = all_of(value_cols), names_to = "Metric_EN", values_to = "Value")


df_plot <- df_long %>%
  filter(Metric_EN == Initial_Var) %>%
  group_by(Initial_Var, Level, Agent) %>%
  mutate(
    Base_Value = Value[Week == 0],    
    Change = Value - Base_Value       
  ) %>%
  group_by(Week, Initial_Var, Level) %>%
  summarise(Mean_Change = mean(Change, na.rm = TRUE), .groups = "drop")


df_plot$Level_F <- factor(df_plot$Level, levels = c(1, 2, 3, 4, 5))

# ==============================================================================
# 2. 
# ==============================================================================

PALETTES <- list(
  Patriotism = c("#4b0082", "#7c2f76", "#f3b12b"),
  
  # Dedication: 
  Dedication = c("#004d00", "#556B2F", "#3851a1"),
  
  # Integrity: 
  Integrity  = c("#004D40", "#4A7055", "#FCEA9A"),
  
  # Kindness: 
  Kindness   = c("#00008B", "#008B8B","#006400"),
  
  # CourseGain: 
  CourseGain = c("#80A577", "#28505B", "#2A998E")
)

# ==============================================================================
# 3. 绘图函数 (核心修改部分)
# ==============================================================================
create_heatmap_individual <- function(data, var_name, title_text, colors) {
  
  sub_data <- data %>% filter(Initial_Var == var_name)
  
  if(nrow(sub_data) == 0) return(ggplot() + theme_void())
  
  # 计算颜色范围限制
  limit <- max(abs(sub_data$Mean_Change), na.rm = TRUE)
  if(limit < 0.01) limit <- 0.01 
  
  ggplot(sub_data, aes(x = Week, y = Level_F, fill = Mean_Change)) +
    
    # 1. 修复 size 警告：改用 linewidth
    geom_tile(color = "gray", linewidth = 0.2) +
    
    # 2. 修复字体报错：family 改为 "sans"
    geom_text(aes(
      label = sprintf("%.4f", Mean_Change)), 
      size = 2, 
      fontface = "plain",
      angle = 270,
      family = "sans" # <--- 修改这里，避免 PostScript 报错
    ) +
    
    # 设置颜色渐变
    scale_fill_gradientn(
      colors = colors,
      limits = c(-limit, limit),
      values = c(0, 0.5, 1),
      oob = scales::squish,
      name = expression(Delta)
    ) +
    
    scale_x_continuous(expand = c(0, 0), breaks = seq(0, 52, 10)) +
    scale_y_discrete(expand = c(0, 0)) +
    
    labs(
      title = title_text,
      x = "Week",
      y = "Initial Level"
    ) +
    
    # 主题设置
    theme_minimal(base_size = 10, base_family = "sans") + # <--- 确保主题也用 sans
    
    theme(
      plot.title = element_text(size = 11, hjust = 0.5), # 标题居中
      axis.title = element_text(size = 9),
      axis.text = element_text(color = "black", size = 8),
      panel.grid = element_blank(),
      
      # --- 【核心修改：图例位置设置】 ---
      legend.position = "top",         # 放在顶部区域
      legend.justification = "right",  # 在顶部区域中靠右对齐
      legend.direction = "horizontal", # 图例条横向摆放
      
      # 调整图例尺寸和外边距，使其紧凑
      legend.key.height = unit(0.3, "cm"), # 高度调小一点
      legend.key.width = unit(0.8, "cm"),  # 宽度调大一点（方便看渐变）
      legend.title = element_text(size = 9, vjust = 0.8), # 微调标题对齐
      legend.text = element_text(size = 7),
      legend.margin = margin(0, 0, 0, 0), # 去除图例周围多余留白
      
      plot.margin = margin(5, 10, 5, 5)
    )
}

# ==============================================================================
# 4. 生成 5 张图
# ==============================================================================
p1 <- create_heatmap_individual(df_plot, "Patriotism", "Patriotism", PALETTES$Patriotism)
p2 <- create_heatmap_individual(df_plot, "Dedication", "Dedication", PALETTES$Dedication)
p3 <- create_heatmap_individual(df_plot, "Integrity", "Integrity", PALETTES$Integrity)
p4 <- create_heatmap_individual(df_plot, "Kindness", "Kindness", PALETTES$Kindness)
p5 <- create_heatmap_individual(df_plot, "CourseGain", "Course Gain", PALETTES$CourseGain)

# ==============================================================================
# 5. 拼图并保存
# ==============================================================================
final_plot <- wrap_plots(p1, p2, p3, p4, p5, ncol = 1) 
final_plot
# 保存
ggsave("tu4.2 Horizontal_Legend2.pdf", 
       plot = final_plot, 
       device = cairo_pdf, 
       width = 10, 
       height = 15,  #稍微增加一点高度给图例腾空间
       units = "in",
       dpi = 600)

#######4.2
# # ==============================================================================
# # 1.     ׼  
# # ==============================================================================
# file_name <- "ʱ          .csv"
# df <- read_csv(file_name, show_col_types = FALSE)
# 
# # ӳ   ֵ 
# term_mapping <- c(
#   "      ֵ  " = "Patriotism", "Patriotism" = "Patriotism",
#   "  ҵ  ֵ  " = "Dedication", "Dedication" = "Dedication",
#   "   ż ֵ  " = "Integrity",  "Integrity"  = "Integrity",
#   "   Ƽ ֵ  " = "Kindness",   "Friendliness" = "Kindness", "kindness" = "Kindness", "Kindness" = "Kindness",
#   "˼   λ  ø " = "CourseGain", "CourseGain" = "CourseGain", "CourseGains" = "CourseGain"
# )
# 
# #   ϴ    
# df_clean <- df %>%
#   rename(
#     Initial_Col = initial, Level = value, Week = week, Agent = agent,
#     Patriotism = any_of(c("      ֵ  ", "Patriotism")),
#     Dedication = any_of(c("  ҵ  ֵ  ", "Dedication")),
#     Integrity  = any_of(c("   ż ֵ  ", "Integrity")),
#     Kindness   = any_of(c("   Ƽ ֵ  ", "Friendliness", "kindness", "Kindness")),
#     CourseGain = any_of(c("˼   λ  ø ", "CourseGain", "CourseGains"))
#   )
# df_clean$Initial_Var <- term_mapping[df_clean$Initial_Col]
# 
# #     ת   &      仯��
# value_cols <- c("Patriotism", "Dedication", "Integrity", "Kindness", "CourseGain")
# df_long <- df_clean %>%
#   pivot_longer(cols = all_of(value_cols), names_to = "Metric_EN", values_to = "Value") %>%
#   filter(Metric_EN == Initial_Var) %>%
#   group_by(Initial_Var, Level, Agent) %>%
#   mutate(
#     Base_Value = Value[Week == 0],   
#     Change = Value - Base_Value      
#   ) %>%
#   group_by(Week, Initial_Var, Level) %>%
#   summarise(Mean_Change = mean(Change, na.rm = TRUE), .groups = "drop")
# 
# #   ע ⡿   ﲻ ٽ  Level   Ϊ   ӣ    Ǳ   Ϊ  ֵ   Ա     ƽ    ֵ
# # df_plot$Level      numeric      (1, 2, 3, 4, 5)
# 
# # ==============================================================================
# # 2.       ɫ  ɫ      ɫ (Hex Codes)
# # ==============================================================================
# PALETTES <- list(
#   Patriotism = c("#00008B", "#800080", "#8B0000"), # Blue-Purple-Red
#   Dedication = c("#004d00", "#556B2F", "#8B4513"), # Green-Olive-Brown
#   Integrity  = c("#004D40", "#483D8B", "#C2185B"), # Teal-Slate-Pink
#   Kindness   = c("#006400", "#008B8B", "#00008B"), # Green-Teal-Blue
#   CourseGain = c("#4A148C", "#800000", "#CC5500")  # Purple-Maroon-Orange
# )
# 
# # ==============================================================================
# # 3.   ͼ      ƽ        ��ͼ (Smoothed Heatmap)
# # ==============================================================================
# create_smooth_heatmap <- function(data, var_name, title_text, colors) {
#   
#   sub_data <- data %>% filter(Initial_Var == var_name)
#   
#   if(nrow(sub_data) == 0) return(ggplot() + theme_void())
#   
#   limit <- max(abs(sub_data$Mean_Change), na.rm = TRUE)
#   if(limit < 0.01) limit <- 0.01 
#   
#   ggplot(sub_data, aes(x = Week, y = Level, fill = Mean_Change)) +
#     
#     # ---      ޸ģ ʹ   geom_raster         ֵ ---
#     # interpolate = TRUE    Զ      ؽ   ƽ     ���       ݺͷ     
#     geom_raster(interpolate = TRUE) +
#     
#     #   ѡ     ӵȸ    (        Ҫ ȸ  ߣ     ע ͵       һ  )
#     # geom_contour(aes(z = Mean_Change), color = "white", alpha = 0.2, size = 0.2) +
#     
#     scale_fill_gradientn(
#       colors = colors,
#       limits = c(-limit, limit),
#       values = c(0, 0.5, 1),
#       oob = scales::squish,
#       name = expression(Delta)
#     ) +
#     
#     scale_x_continuous(expand = c(0, 0), breaks = seq(0, 52, 10)) +
#     # Y    ʽָ   1-5    ֤  ʾ    
#     scale_y_continuous(expand = c(0, 0), breaks = 1:5, labels = 1:5) +
#     
#     labs(
#       title = title_text,
#       x = "Week",
#       y = "Init. Level"
#     ) +
#     
#     theme_minimal(base_family = "sans", base_size = 10) +
#     theme(
#       plot.title = element_text( size = 11, hjust = 0),
#       axis.title = element_text(size = 9, face = "bold"),
#       axis.text = element_text(color = "black", size = 8),
#       panel.grid = element_blank(), # ƽ  ͼ    Ҫ    
#       
#       legend.position = "right",
#       legend.key.height = unit(0.8, "cm"),
#       legend.key.width = unit(0.3, "cm"),
#       legend.title = element_text(size = 9, face = "bold"),
#       legend.text = element_text(size = 7),
#       
#       plot.margin = margin(5, 10, 5, 5)
#     )
# }
# 
# # ==============================================================================
# # 4.       ƴͼ
# # ==============================================================================
# p1 <- create_smooth_heatmap(df_plot, "Patriotism", "a) Patriotism", PALETTES$Patriotism)
# p2 <- create_smooth_heatmap(df_plot, "Dedication", "b) Dedication", PALETTES$Dedication)
# p3 <- create_smooth_heatmap(df_plot, "Integrity", "c) Integrity", PALETTES$Integrity)
# p4 <- create_smooth_heatmap(df_plot, "Kindness", "d) Kindness", PALETTES$Kindness)
# p5 <- create_smooth_heatmap(df_plot, "CourseGain", "e) Course Gain", PALETTES$CourseGain)
# 
# final_plot <- wrap_plots(p1, p2, p3, p4, p5, ncol = 3) +
#   plot_annotation(
#     title = "Temporal Dynamics: Smoothed Evolution Trends",
#     subtitle = "Interpolated gradients visualize the continuous flow of value changes.",
#     theme = theme(
#       plot.title = element_text(size = 14,  hjust = 0.5),
#       plot.subtitle = element_text(size = 10, hjust = 0.5, color = "gray30")
#     )
#   )
# final_plot
# #     
# ggsave("Figure_Temporal_Smoothed.pdf", plot = final_plot, width = 12, height = 7, dpi = 300, device = cairo_pdf)
# ggsave("Figure_Temporal_Smoothed.png", plot = final_plot, width = 12, height = 7, dpi = 300)
# 
# print(final_plot)

#####4.2

# ==============================================================================
# 0.    ر Ҫ İ 
# ==============================================================================
library(ggplot2)
library(dplyr)
library(tidyr)
library(readr)
library(stringr)
library(patchwork)

# ==============================================================================
# 1.     ׼   (Data Preparation)
# ==============================================================================
file_name <- "ʱ          .csv"
df <- read_csv(file_name, show_col_types = FALSE)

# --- ӳ   ֵ  ---
term_mapping <- c(
  "      ֵ  " = "Patriotism", "Patriotism" = "Patriotism",
  "  ҵ  ֵ  " = "Dedication", "Dedication" = "Dedication",
  "   ż ֵ  " = "Integrity",  "Integrity"  = "Integrity",
  "   Ƽ ֵ  " = "Kindness",   "Friendliness" = "Kindness", "kindness" = "Kindness", "Kindness" = "Kindness",
  "˼   λ  ø " = "CourseGain", "CourseGain" = "CourseGain", "CourseGains" = "CourseGain"
)

# 1.   ϴ        
df_clean <- df %>%
  rename(
    Initial_Col = initial, Level = value, Week = week, Agent = agent,
    Patriotism = any_of(c("      ֵ  ", "Patriotism")),
    Dedication = any_of(c("  ҵ  ֵ  ", "Dedication")),
    Integrity  = any_of(c("   ż ֵ  ", "Integrity")),
    Kindness   = any_of(c("   Ƽ ֵ  ", "Friendliness", "kindness", "Kindness")),
    CourseGain = any_of(c("˼   λ  ø ", "CourseGain", "CourseGains"))
  )
df_clean$Initial_Var <- term_mapping[df_clean$Initial_Col]

# 2.     ת   &      仯��
value_cols <- c("Patriotism", "Dedication", "Integrity", "Kindness", "CourseGain")
df_long <- df_clean %>%
  pivot_longer(cols = all_of(value_cols), names_to = "Metric_EN", values_to = "Value") %>%
  filter(Metric_EN == Initial_Var) %>% # ֻ     Խ       
  group_by(Initial_Var, Level, Agent) %>%
  mutate(
    Base_Value = Value[Week == 0],   
    Change = Value - Base_Value      
  ) %>%
  group_by(Week, Initial_Var, Level) %>%
  summarise(Mean_Change = mean(Change, na.rm = TRUE), .groups = "drop")

#    ؼ   Y          ֵ Ͳ  ܻ  ȸ   
# df_long$Level          numeric (1,2,3,4,5)      ת    
#     ֮ǰת     factor          ת   numeric  

# ==============================================================================
# 2.       ɫ ߱     ɫ  ɫ (ʹ    ֮ǰѡ   ķ   )
# ==============================================================================
PALETTES <- list(
  # 1. Patriotism (Blue-Purple-Red)
  Patriotism = c("#00008B", "#800080", "#8B0000"),
  
  # 2. Dedication (Green-Olive-Brown)
  Dedication = c("#004d00", "#556B2F", "#8B4513"),
  
  # 3. Integrity (Teal-Slate-Pink)
  Integrity  = c("#004D40", "#483D8B", "#C2185B"),
  
  # 4. Kindness (Indigo-Magenta-Brick)
  Kindness   = c("#4B0082", "#C71585", "#B22222"),
  
  # 5. CourseGain (Purple-Maroon-Orange)
  CourseGain = c("#4A148C", "#800000", "#CC5500")
)

# ==============================================================================
# 3.   ͼ       ȸ  ߵ   ͼ (Contour Map)
# ==============================================================================
create_contour_map <- function(data, var_name, title_text, colors) {
  
  sub_data <- data %>% filter(Initial_Var == var_name)
  
  if(nrow(sub_data) == 0) return(ggplot() + theme_void())
  
  #       ɫ  Χ
  limit <- max(abs(sub_data$Mean_Change), na.rm = TRUE)
  if(limit < 0.01) limit <- 0.01 
  
  ggplot(sub_data, aes(x = Week, y = Level, z = Mean_Change)) +
    
    # --- 1.  ײ㣺ƽ        ��ͼ ---
    # interpolate = TRUE   ֤  ɫ��      
    geom_raster(aes(fill = Mean_Change), interpolate = TRUE) +
    
    # --- 2.    㣺 ȸ    (White Contours) ---
    # color="white": ʹ ð ɫ    
    # alpha=0.4:       ͸                
    # size=0.2:       ϸ
    # bins=10:  Զ     Լ10   㼶
    geom_contour(color = "white", alpha = 0.6, size = 0.3, bins = 15) +
    
    #   ɫӳ   (Deep 3-Tone)
    scale_fill_gradientn(
      colors = colors,
      limits = c(-limit, limit),
      values = c(0, 0.5, 1),
      oob = scales::squish,
      name = expression(Delta)
    ) +
    
    scale_x_continuous(expand = c(0, 0), breaks = seq(0, 52, 10)) +
    scale_y_continuous(expand = c(0, 0), breaks = 1:5, labels = 1:5) +
    
    labs(
      title = title_text,
      x = "Week",
      y = "Init. Level"
    ) +
    
    theme_minimal(base_family = "sans", base_size = 10) +
    theme(
      plot.title = element_text( size = 11, hjust = 0),
      axis.title = element_text(size = 9, face = "bold"),
      axis.text = element_text(color = "black", size = 8),
      panel.grid = element_blank(), #  ȸ   ͼ    Ҫ   񱳾 
      
      legend.position = "right",
      legend.key.height = unit(0.8, "cm"),
      legend.key.width = unit(0.3, "cm"),
      legend.title = element_text(size = 9, face = "bold"),
      legend.text = element_text(size = 7),
      
      plot.margin = margin(5, 10, 5, 5)
    )
}

# ==============================================================================
# 4.      5     ͼ  ƴ  
# ==============================================================================
p1 <- create_contour_map(df_plot, "Patriotism", "a) Patriotism", PALETTES$Patriotism)
p2 <- create_contour_map(df_plot, "Dedication", "b) Dedication", PALETTES$Dedication)
p3 <- create_contour_map(df_plot, "Integrity", "c) Integrity", PALETTES$Integrity)
p4 <- create_contour_map(df_plot, "Kindness", "d) Kindness", PALETTES$Kindness)
p5 <- create_contour_map(df_plot, "CourseGain", "e) Course Gain", PALETTES$CourseGain)

#    ֣      ¶ 
final_plot <- wrap_plots(p1, p2, p3, p4, p5, ncol = 3) +
  plot_annotation(
    title = "Temporal Dynamics: Contour Evolution Map",
    subtitle = "Iso-lines represent zones of equal value change. Gradients show continuous evolution.",
    theme = theme(
      plot.title = element_text(size = 14,  hjust = 0.5),
      plot.subtitle = element_text(size = 10, hjust = 0.5, color = "gray30")
    )
  )
final_plot
# ==============================================================================
# 5.         
# ==============================================================================
ggsave("Figure_Temporal_ContourMap.pdf", plot = final_plot, width = 12, height = 7, dpi = 300, device = cairo_pdf)
ggsave("Figure_Temporal_ContourMap.png", plot = final_plot, width = 12, height = 7, dpi = 300)

print(final_plot)






###########################4.3
###########################4.3
###########################4.3
library(ggplot2)
library(dplyr)
library(tidyr)
library(readr)
library(stringr)
library(patchwork)

# ==============================================================================
# 0.        ã             
# ==============================================================================
# 1. ע   Arial      (Windows     )
if(.Platform$OS.type == "windows") {
  windowsFonts(Arial = windowsFont("Arial"))
}
# ==============================================================================
# 1.     ׼   (Data Preparation)
# ==============================================================================
file_name <- "ʱ       ⲿ    .csv"
df <- read_csv(file_name, show_col_types = FALSE)

#   ϴ        
df_clean <- df %>%
  rename(
    Initial_Col = initial, 
    Level = 2,            
    Week = week, 
    Agent = agent,
    #    ݴ Сд
    Patriotism = any_of(c("      ֵ  ", "Patriotism")),
    Dedication = any_of(c("  ҵ  ֵ  ", "Dedication")),
    Integrity  = any_of(c("   ż ֵ  ", "Integrity")),
    Kindness   = any_of(c("   Ƽ ֵ  ", "Friendliness", "kindness", "Kindness")),
    CourseGain = any_of(c("˼   λ  ø ", "CourseGain", "CourseGains"))
  )

df_clean$Initial_Var <- df_clean$Initial_Col

#     ת   &      仯�� (ֻ   CourseGain)
value_cols <- c("Patriotism", "Dedication", "Integrity", "Kindness", "CourseGain")
df_long <- df_clean %>%
  pivot_longer(cols = any_of(value_cols), names_to = "Metric_EN", values_to = "Value") %>%
  filter(Metric_EN == "CourseGain") %>%
  group_by(Initial_Var, Level, Agent) %>%
  mutate(
    Base_Value = Value[Week == 0],    
    Change = Value - Base_Value       
  ) %>%
  group_by(Week, Initial_Var, Level) %>%
  summarise(Mean_Change = mean(Change, na.rm = TRUE), .groups = "drop")

# ==============================================================================
# 2.   ɫ    
# ==============================================================================
PALETTES <- list(
  PartyInterval   = c("#00008B", "#800080", "#8B0000"),
  FamilyDuration  = c("#004d00", "#556B2F", "#8B4513"),
  MediaExposure   = c("#004D40", "#483D8B", "#C2185B"),
  CourseFrequency = c("#4B0082", "#C71585", "#B22222"),
  PeerDuration    = c("#191970", "#9400D3", "#800000")
)

# ==============================================================================
# 3.   ͼ        λС    ǩ + Arial     
# ==============================================================================

create_contour_map <- function(data, var_name, title_text, colors) {
  
  sub_data <- data %>% filter(Initial_Var == var_name)
  
  if(nrow(sub_data) == 0) return(ggplot() + theme_void())
  
  #   ̬   㷶Χ
  limit <- max(abs(sub_data$Mean_Change), na.rm = TRUE)
  if(limit < 0.01) limit <- 0.01 
  
  ggplot(sub_data, aes(x = Week, y = Level, z = Mean_Change)) +
    
    # 1.  ײ㣺ƽ    ��ͼ
    geom_raster(aes(fill = Mean_Change), interpolate = TRUE) +
    
    # 2. ϸ ȸ    (װ  )
    geom_contour(color = "white", alpha = 0.2, linewidth = 0.1, bins = 20) +
    
    # 3.  ֵȸ    (  ֵ  ׼)
    geom_contour(color = "white", alpha = 0.6, linewidth = 0.3, bins = 6) +
    
    # 4.  ȸ  ߱ ǩ ( ռ     )
    geom_text_contour(
      aes(label = sprintf("%.4f", after_stat(level))), 
      color = "white",       
      
      #         
      size = 2.0,            
      family = "Arial",      
      
      #           1  : ʹ   label_placer_n(1)
      #    壺ǿ    ÿһ   ȸ        ٷ    1     ǩ
      #    ܽ     С   족 ȸ  ߲   ʾ  ǩ      
      label.placer = label_placer_n(1),
      
      #           2  :  Ƴ  label.padding (        )
      
      #     ǿ    ʾ    
      check_overlap = FALSE, #  ر  ص    ⣬  ֹ  ǩ    
      skip = 0,              #        κβ㼶
      min.size = 0,          #      ˶   
      bins = 6               
    ) +
    
    #   ɫӳ  
    scale_fill_gradientn(
      colors = colors,
      limits = c(-limit, limit),
      values = c(0, 0.5, 1),
      oob = scales::squish,
      name = expression(Delta)
    ) +
    
    scale_x_continuous(expand = c(0, 0), breaks = seq(0, 52, 10)) +
    scale_y_continuous(expand = c(0, 0), breaks = 1:5, labels = 1:5) +
    
    labs(
      title = title_text,
      x = "Week",
      y = "Init. Level"
    ) +
    
    theme_minimal(base_family = "Arial", base_size = 10) +
    theme(
      plot.title = element_text(size = 11, hjust = 0),
      axis.title = element_text(size = 9, face = "bold"),
      axis.text = element_text(color = "black", size = 8),
      panel.grid = element_blank(),
      
      legend.position = "right",
      legend.key.height = unit(0.8, "cm"),
      legend.key.width = unit(0.3, "cm"),
      legend.title = element_text(size = 9, face = "bold"),
      legend.text = element_text(size = 7),
      
      plot.margin = margin(5, 10, 5, 5)
    )
}
# ==============================================================================
# 4.       ͼ
# ==============================================================================
p1 <- create_contour_map(df_long, "PartyInterval",   "a. Party Activity Interval",   PALETTES$PartyInterval)
p2 <- create_contour_map(df_long, "FamilyDuration",  "b. Duration of Family Interaction", PALETTES$FamilyDuration)
p3 <- create_contour_map(df_long, "MediaExposure",   "c. Duration of Media Exposure",   PALETTES$MediaExposure)
p4 <- create_contour_map(df_long, "CourseFrequency", "d. Frequency of Ideological Courses", PALETTES$CourseFrequency)
p5 <- create_contour_map(df_long, "PeerDuration",    "e. Duration of Peer Interaction",    PALETTES$PeerDuration)

# ==============================================================================
# 5. ƴͼ 뵼  
# ==============================================================================
final_plot <- wrap_plots(p1, p2, p3, p4, p5, ncol = 3) 
final_plot
# ʹ   cairo_pdf ȷ      ʱ Arial    岻  ʧ
ggsave("tu4.3 Arial.pdf", 
       final_plot, width = 13, height = 6, 
       device = cairo_pdf,dpi = 600)


#########################
#########################
#########################4.4
# ==============================================================================
# 1.     ׼  
# ==============================================================================
packages <- c("ggplot2", "dplyr", "tidyr", "readr", "ggsci", "patchwork")
new_packages <- packages[!(packages %in% installed.packages()[,"Package"])]
if(length(new_packages)) install.packages(new_packages)

library(ggplot2)
library(dplyr)
library(tidyr)
library(readr)
library(ggsci)
library(patchwork)

# ==============================================================================
# 2.    ݶ ȡ 봦  
# ==============================================================================
df <- read_csv("ʱ          .csv", show_col_types = FALSE)

#  淶      
df <- df %>% 
  rename_with(~ "Kindness", .cols = any_of("kindness")) %>%
  mutate(initial = ifelse(initial == "kindness", "Kindness", initial))

#   ��ӳ  
variable_labels <- c(
  "PartyInterval"   = "Party Activity",
  "FamilyDuration"  = "Family Interaction",
  "MediaExposure"   = "Media Exposure",
  "CourseFrequency" = "Course Frequency",
  "PeerDuration"    = "Peer Interaction",
  "Patriotism"      = "Patriotism (Int)",
  "Dedication"      = "Dedication (Int)",
  "Integrity"       = "Integrity (Int)",
  "Kindness"        = "Kindness (Int)",
  "CourseGain"      = "Course Gain (Int)"
)

external_vars <- c("Party Activity", "Family Interaction", "Media Exposure", 
                   "Course Frequency", "Peer Interaction")
outcomes <- c("Patriotism", "Dedication", "Integrity", "Kindness", "CourseGain")

#       52 ܵ Gap
df_summary <- df %>%
  filter(week == 52) %>%
  filter(value %in% c(1, 5)) %>%
  select(initial, value, agent, any_of(outcomes)) %>%
  pivot_longer(cols = any_of(outcomes), names_to = "Outcome_Var", values_to = "Score") %>%
  pivot_wider(names_from = value, values_from = Score, names_prefix = "L") %>%
  mutate(Gap = L5 - L1) %>%
  mutate(Input_Name = variable_labels[initial]) %>%
  mutate(Type = ifelse(Input_Name %in% external_vars, "External", "Internal")) %>%
  group_by(Input_Name, Type, Outcome_Var) %>%
  summarise(
    Mean_Gap = mean(Gap, na.rm = TRUE),
    SE_Gap = sd(Gap, na.rm = TRUE) / sqrt(n()),
    .groups = "drop"
  )

# ==============================================================================
# 3.   ͼ     (Arial     +  ޼Ӵ )
# ==============================================================================
create_final_bar_plot <- function(outcome_name, remove_input_name, prefix) {
  
  # ɸѡ    
  plot_data <- df_summary %>% 
    filter(Outcome_Var == outcome_name) %>%
    filter(Input_Name != remove_input_name) 
  
  #         
  full_title <- paste0(prefix, ". ", outcome_name)
  
  p <- ggplot(plot_data, aes(x = reorder(Input_Name, Mean_Gap), y = Mean_Gap, fill = Type)) +
    
    # 1.   ״ͼ
    geom_bar(stat = "identity", width = 0.7, alpha = 0.9) +
    
    # 2.       
    geom_errorbar(aes(ymin = Mean_Gap - SE_Gap, ymax = Mean_Gap + SE_Gap),
                  width = 0.2, color = "black", size = 0.3) +
    
    # 3.   ֵ  ǩ ( ޼Ӵ֣ Arial)
    geom_text(aes(label = sprintf("%.4f", Mean_Gap)), 
              hjust = -0.2,  
              size = 3,
              family = "sans", #   Ӧ Arial
              color = "black") + # ɾ     fontface = "bold"
    
    # 4.      ᷭת
    coord_flip() + 
    
    # 5.   ɫ
    scale_fill_manual(values = c("External" = "#4DBBD5FF", "Internal" = "#E64B35FF")) +
    
    # 6. Y  ��  
    scale_y_continuous(expand = expansion(mult = c(0.05, 0.3))) + 
    
    # 7.   ǩ
    labs(title = full_title, x = NULL, y = NULL) +
    
    # 8.          (ȫ        Ϊ sans/Arial)
    theme_bw(base_size = 12, base_family = "sans") + # base_family = "sans" ȷ      Ĭ      Ϊ Arial
    theme(
      #      ( ޼Ӵ )
      plot.title = element_text(face = "plain", size = 14, hjust = 0), 
      
      # ͼ  
      legend.position = "none",
      
      #            ( ޼Ӵ )
      axis.text.y = element_text(color = "black", size = 10, face = "plain"),
      axis.text.x = element_text(color = "black", size = 9, face = "plain"),
      
      # ȥ      
      panel.grid.major.y = element_blank(),
      panel.grid.minor = element_blank()
    )
  
  return(p)
}

# ==============================================================================
# 4.       ͼ
# ==============================================================================
p1 <- create_final_bar_plot("Patriotism", "Patriotism (Int)", "a")
p2 <- create_final_bar_plot("Dedication", "Dedication (Int)", "b")
p3 <- create_final_bar_plot("Integrity", "Integrity (Int)", "c")
p4 <- create_final_bar_plot("Kindness", "Kindness (Int)", "d")
p5 <- create_final_bar_plot("CourseGain", "Course Gain (Int)", "e")

# ==============================================================================
# 5. ƴͼ 뱣  
# ==============================================================================
layout <- (p1 | p2 | p3) / (p4 | p5)
layout 
#     r.png", layout, width = 18, height = 10, dpi = 300)

print(layout)