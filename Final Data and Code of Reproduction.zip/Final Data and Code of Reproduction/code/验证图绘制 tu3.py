import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.lines import Line2D

# --- 1. 关键设置：确保 AI 可编辑 ---
plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['font.family'] = ['Arial', 'SimHei', 'DejaVu Sans'] # 优先使用 Arial
sns.set_context("paper", font_scale=1.4) # 调整字体大小适合论文
sns.set_style("ticks")

# --- 2. 读取数据 ---
# 请确保这两个文件在当前目录下
df_mean = pd.read_csv('均值汇总表total.csv')
df_jitter = pd.read_csv('验证数据汇总表jitter.csv')

# --- 3. 数据预处理 ---
# 维度映射 (中文 -> 英文 SCI 格式)
col_map = {
    '爱国价值观': 'Patriotism',
    '敬业价值观': 'Dedication',
    '诚信价值观': 'Integrity',
    '友善价值观': 'Friendliness',
    '思政课获得感': 'Course Gains'
}

# 3.1 准备图 1 数据 (Distribution)
jitter_cols = ['序号'] + list(col_map.keys())
# 提取并重命名列
df_sim_jitter = df_jitter[jitter_cols].rename(columns=col_map)
# 转换为长格式 (Melt) 以便 Seaborn 绘图
df_melt = df_sim_jitter.melt(id_vars=['序号'], var_name='Dimension', value_name='Value')

# 3.2 准备图 2 数据 (Accuracy Stats)
# 提取真实值 (real 行)
real_row = df_mean[df_mean['序号'] == 'real'].iloc[0]
real_vals = [real_row[c] for c in col_map.keys()]

# 提取模拟均值 (sim1-sim12 行)
sim_rows = df_mean[df_mean['序号'].str.contains('sim', na=False)]

# 计算模拟的均值和标准差
sim_stats = pd.DataFrame()
sim_stats['Dimension'] = list(col_map.values())
sim_stats['Real_Value'] = real_vals
sim_stats['Sim_Mean'] = [sim_rows[c].mean() for c in col_map.keys()]
sim_stats['Sim_Std'] = [sim_rows[c].std() for c in col_map.keys()]


# --- 4. 绘图 1: 模型稳健性与异质性 (Robustness & Heterogeneity) ---
fig1, ax1 = plt.subplots(figsize=(12, 7))

# 图层 A: 散点云 (展示所有 Agent，体现丰富性)
sns.stripplot(data=df_melt, x='Dimension', y='Value', ax=ax1,
              jitter=0.25, size=3, alpha=0.2, color='#85C1E9', zorder=1)

# 图层 B: 箱线图 (展示统计分布)
# 设为透明填充，只显示深蓝色边框
sns.boxplot(data=df_melt, x='Dimension', y='Value', ax=ax1,
            showfliers=False, width=0.5,
            boxprops=dict(facecolor=(0,0,0,0), edgecolor='#2E86C1', linewidth=2.5),
            whiskerprops=dict(color='#2E86C1', linewidth=2),
            capprops=dict(color='#2E86C1', linewidth=2),
            medianprops=dict(color='#2E86C1', linewidth=2), zorder=2)

# 图层 C: 真实均值 (红钻)
# 将维度名称映射为 x 轴坐标 (0, 1, 2...)
dim_to_x = {d: i for i, d in enumerate(sim_stats['Dimension'])}
ax1.scatter(x=[dim_to_x[d] for d in sim_stats['Dimension']],
            y=sim_stats['Real_Value'],
            color='#C0392B', s=180, marker='D',
            edgecolor='white', linewidth=1.5, zorder=10, label='Empirical Mean')

# 美化
ax1.set_title('Figure 1. Model Robustness: Population Heterogeneity vs. Empirical Data', fontsize=16, fontweight='bold', pad=15)
ax1.set_ylabel('Annual Change Value ($\Delta v$)', fontsize=14)
ax1.set_xlabel('')
ax1.axhline(0, color='gray', linestyle='--', linewidth=1, alpha=0.5)

# 自定义图例
legend_elements = [
    Line2D([0], [0], marker='o', color='w', markerfacecolor='#85C1E9', label='Simulated Agents (n=360)', markersize=8),
    Line2D([0], [0], color='#2E86C1', lw=2.5, label='Simulation Distribution (IQR)'),
    Line2D([0], [0], marker='D', color='w', markerfacecolor='#C0392B', label='Empirical Mean (2024)', markersize=10)
]
ax1.legend(handles=legend_elements, loc='upper left', frameon=True, fontsize=12)

sns.despine()
plt.tight_layout()
plt.savefig('Figure_1_Robustness.pdf', format='pdf', transparent=True)
plt.show()


# --- 5. 绘图 2: 预测准确性 (Predictive Accuracy) ---
fig2, ax2 = plt.subplots(figsize=(9, 9))

# 误差棒图 (X=真实, Y=模拟)
ax2.errorbar(sim_stats['Real_Value'], sim_stats['Sim_Mean'],
             yerr=sim_stats['Sim_Std'], fmt='o',
             color='#2E86C1', ecolor='#5DADE2', elinewidth=2, capsize=5,
             markersize=12, label='Model Prediction')

# 完美预测线 (y=x)
min_val = min(sim_stats['Real_Value'].min(), sim_stats['Sim_Mean'].min()) - 0.05
max_val = max(sim_stats['Real_Value'].max(), sim_stats['Sim_Mean'].max()) + 0.05
ax2.plot([min_val, max_val], [min_val, max_val], 'k--', alpha=0.4, label='Perfect Fit (y=x)')

# 文字标注 (为了防止文字重叠，这里手动设置了偏移量)
offsets = {
    'Integrity': (-60, -10),
    'Patriotism': (15, -10),
    'Course Gains': (15, 0),
    'Dedication': (15, 5),
    'Friendliness': (-90, 10)
}

for _, row in sim_stats.iterrows():
    txt = row['Dimension']
    off = offsets.get(txt, (5, 5))
    ax2.annotate(txt, (row['Real_Value'], row['Sim_Mean']), xytext=off,
                 textcoords='offset points', fontsize=12)

# 美化
ax2.set_title('Figure 2. Predictive Accuracy: Simulation vs. Observation', fontsize=16, fontweight='bold', pad=15)
ax2.set_xlabel('Observed Real Change', fontsize=14)
ax2.set_ylabel('Simulated Change (Mean $\pm$ SD)', fontsize=14)
ax2.legend(loc='lower right', fontsize=12)
ax2.grid(True, linestyle=':', alpha=0.6)

sns.despine()
plt.tight_layout()
plt.savefig('Figure_2_Accuracy.pdf', format='pdf', transparent=True)
plt.show()